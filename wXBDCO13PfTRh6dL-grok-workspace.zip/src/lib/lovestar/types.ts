export type Lang = "uk" | "en";

export type Goal = "serious" | "dates" | "chat" | "friends";

export type Looking = "women" | "men" | "everyone";

export type Tab = "discover" | "matches" | "premium" | "me";

export type Profile = {
  name: string;
  age: number;
  country: string;
  city: string;
  looking: Looking;
  goal: Goal;
  interests: string[];
  bio: string;
};

export type Filters = {
  ageMin: number;
  ageMax: number;
  goal: Goal | "any";
  sameCountry: boolean;
};

export type ChatMsg = {
  from: "me" | "them";
  text: string;
  at: number;
};

export type Report = {
  id: string;
  reason: string;
  at: number;
};
