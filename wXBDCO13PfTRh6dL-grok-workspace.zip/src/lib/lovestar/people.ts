import type { Filters, Goal, Profile } from "./types";

export const COUNTRY_IDS = ["ua", "pl", "de", "es", "fr", "it", "jp", "nl", "pt", "gb", "us"] as const;

export const CITIES: Record<string, readonly string[]> = {
  ua: ["kyiv", "lviv", "odesa", "dnipro"],
  pl: ["warsaw", "krakow"],
  de: ["berlin", "munich"],
  es: ["barcelona", "madrid"],
  fr: ["paris", "lyon"],
  it: ["milan", "rome"],
  jp: ["tokyo", "osaka"],
  nl: ["amsterdam"],
  pt: ["lisbon"],
  gb: ["london"],
  us: ["newyork"],
};

export const INTEREST_IDS = [
  "music",
  "travel",
  "coffee",
  "sport",
  "cinema",
  "books",
  "cooking",
  "art",
  "hiking",
  "photo",
  "dance",
  "design",
  "food",
  "languages",
] as const;

export type Person = {
  id: string;
  name: string;
  age: number;
  gender: "woman" | "man";
  country: string;
  city: string;
  goal: Goal;
  interests: string[];
  bio: { uk: string; en: string };
  hello: { uk: string; en: string };
  reply: { uk: string; en: string };
  likedYou: boolean;
};

export const people: Person[] = [
  {
    id: "elena",
    name: "Elena",
    age: 28,
    gender: "woman",
    country: "pl",
    city: "warsaw",
    goal: "dates",
    interests: ["books", "art", "travel"],
    bio: {
      uk: "Редакторка у Варшаві. Люблю довгі книжки й короткі прогулянки після роботи.",
      en: "Editor in Warsaw. Long books, and a short walk after work.",
    },
    hello: {
      uk: "Вітаю. Що ти зараз читаєш — або навмисно не читаєш?",
      en: "Hello. What are you reading — or deliberately not reading?",
    },
    reply: {
      uk: "Добре. Тоді без дрібниць: що тебе зараз справді займає?",
      en: "Good. Then skip the small talk: what actually has your attention?",
    },
    likedYou: false,
  },
  {
    id: "sofia",
    name: "Sofia",
    age: 26,
    gender: "woman",
    country: "ua",
    city: "kyiv",
    goal: "serious",
    interests: ["design", "coffee", "cinema"],
    bio: {
      uk: "Дизайнерка з Києва. Шукаю спокійні вечори й людину, з якою не треба вдавати.",
      en: "Designer in Kyiv. Quiet evenings, and someone I don’t have to perform for.",
    },
    hello: {
      uk: "Привіт. У твоїй анкеті немає пози. Як твій вечір?",
      en: "Hi. Your profile isn’t posing. How’s your evening?",
    },
    reply: {
      uk: "Мені близькі спокійні люди. Що в тебе цього тижня не для галочки?",
      en: "Calm people suit me. What’s on your week that isn’t for show?",
    },
    likedYou: true,
  },
  {
    id: "luca",
    name: "Luca",
    age: 29,
    gender: "man",
    country: "it",
    city: "milan",
    goal: "dates",
    interests: ["food", "music", "travel"],
    bio: {
      uk: "Готую краще, ніж планую. Шукаю вечерю, яка може стати звичкою.",
      en: "I cook better than I plan. Looking for dinner that might become a habit.",
    },
    hello: {
      uk: "Ciao. Ти більше про довгу вечерю чи каву навстоячки?",
      en: "Ciao. Are you a long dinner, or coffee standing up?",
    },
    reply: {
      uk: "Тоді я ставлю воду, а ти обираєш: паста чи щось простіше.",
      en: "Then I’ll boil the water. You pick: pasta, or something simpler.",
    },
    likedYou: false,
  },
  {
    id: "yara",
    name: "Yara",
    age: 24,
    gender: "woman",
    country: "es",
    city: "barcelona",
    goal: "chat",
    interests: ["dance", "photo", "music"],
    bio: {
      uk: "Танцюю й знімаю місто. Якщо не боїшся спонтанного квитка — напиши.",
      en: "I dance and photograph the city. If a spontaneous ticket doesn’t scare you, say hi.",
    },
    hello: {
      uk: "Гей. Якщо ти в місті цього тижня, я знаю терасу з нормальним світлом.",
      en: "Hey. If you’re in town this week, I know a terrace with decent light.",
    },
    reply: {
      uk: "Ловлю. Назви одне місце, куди пішов би завтра без плану.",
      en: "I’m in. Name one place you’d go tomorrow with no plan.",
    },
    likedYou: true,
  },
  {
    id: "noah",
    name: "Noah",
    age: 32,
    gender: "man",
    country: "de",
    city: "berlin",
    goal: "serious",
    interests: ["art", "hiking", "cinema"],
    bio: {
      uk: "Роблю виставки в Берліні. Цікаві люди зі смаком, не з ідеальною анкетою.",
      en: "I make exhibitions in Berlin. I’m interested in taste, not a perfect profile.",
    },
    hello: {
      uk: "Привіт. Не обов’язково бути в Берліні — цікаво, що обираєш, коли є час.",
      en: "Hey. You don’t have to be in Berlin. I’m curious what you choose when you have time.",
    },
    reply: {
      uk: "Мені цього досить, щоб продовжити. Який у тебе сьогодні темп?",
      en: "That’s enough for me to keep going. What’s your pace today?",
    },
    likedYou: true,
  },
  {
    id: "camille",
    name: "Camille",
    age: 27,
    gender: "woman",
    country: "fr",
    city: "paris",
    goal: "serious",
    interests: ["books", "cooking", "languages"],
    bio: {
      uk: "Працюю з книжками в Парижі. Ціную ясний розум і людей, які відповідають.",
      en: "I work with books in Paris. Clear minds, and people who actually reply.",
    },
    hello: {
      uk: "Привіт. Почни з однієї чесної речі про цей тиждень.",
      en: "Hello. Start with one honest thing about your week.",
    },
    reply: {
      uk: "Чесно — вже краще за більшість чатів. Розкажи ще одну деталь.",
      en: "Honest already beats most chats. Give me one more detail.",
    },
    likedYou: false,
  },
  {
    id: "kenji",
    name: "Kenji",
    age: 30,
    gender: "man",
    country: "jp",
    city: "tokyo",
    goal: "chat",
    interests: ["photo", "design", "coffee"],
    bio: {
      uk: "Знімаю нічне місто й п’ю забагато кави. Хочу розмову, через яку не шкода не спати.",
      en: "I shoot the city at night and drink too much coffee. I want a talk worth losing sleep over.",
    },
    hello: {
      uk: "Привіт. Ніч чи ранок — коли ти найкраще розмовляєш?",
      en: "Hi. Night or morning — when do you actually talk?",
    },
    reply: {
      uk: "Добре звучить. Я ще не сплю — де ти зараз подумки?",
      en: "That sounds right. I’m still up — where is your head right now?",
    },
    likedYou: false,
  },
  {
    id: "omar",
    name: "Omar",
    age: 36,
    gender: "man",
    country: "nl",
    city: "amsterdam",
    goal: "friends",
    interests: ["sport", "cooking", "travel"],
    bio: {
      uk: "Амстердам, багато доріг і нормальна кухня. Спершу жива дружба — далі видно.",
      en: "Amsterdam, too many trains, decent cooking. Friendship first — then we’ll see.",
    },
    hello: {
      uk: "Привіт. Я за прості плани: прогулянка, їжа, без анкети вголос.",
      en: "Hi. Simple plans: a walk, food, no interview voice.",
    },
    reply: {
      uk: "Домовились. Без анкети: кава, вода чи вже вечеря?",
      en: "Deal. No profile talk: coffee, water, or dinner already?",
    },
    likedYou: false,
  },
];

export type DeckSnap = {
  profile: Profile | null;
  filters: Filters;
  likes: string[];
  passes: string[];
  blocked: string[];
};

export function selectPeople(s: DeckSnap, mode: "deck" | "liked") {
  return people.filter((person) => {
    if (s.blocked.includes(person.id)) return false;
    if (s.likes.includes(person.id)) return false;
    if (s.passes.includes(person.id)) return false;
    if (mode === "liked" && !person.likedYou) return false;
    if (s.profile?.looking === "women" && person.gender !== "woman") return false;
    if (s.profile?.looking === "men" && person.gender !== "man") return false;
    if (mode === "deck") {
      if (person.age < s.filters.ageMin || person.age > s.filters.ageMax) return false;
      if (s.filters.goal !== "any" && person.goal !== s.filters.goal) return false;
      if (s.filters.sameCountry && s.profile && person.country !== s.profile.country) return false;
    }
    return true;
  });
}

export function findPerson(id: string) {
  return people.find((person) => person.id === id);
}
