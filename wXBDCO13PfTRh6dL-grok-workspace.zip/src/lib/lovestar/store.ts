import { create } from "zustand";
import { persist } from "zustand/middleware";
import { findPerson } from "./people";
import type { ChatMsg, Filters, Profile, Report, Tab } from "./types";
import type { Lang } from "./types";

export const FREE_CAP = 8;
export const PREMIUM_CAP = 40;

export type ProductId = "likes10" | "boost" | "week" | "month";

export type LikeResult =
  | { ok: true; matched: boolean }
  | { ok: false; reason: "limit" | "seen" };

type State = {
  lang: Lang | null;
  adult: boolean;
  profile: Profile | null;
  likes: string[];
  passes: string[];
  matches: string[];
  blocked: string[];
  reports: Report[];
  premiumUntil: number | null;
  extraLikes: number;
  likesUsedToday: number;
  likeDay: string;
  boostedUntil: number | null;
  messages: Record<string, ChatMsg[]>;
  filters: Filters;
  tab: Tab;
  seenMatchCount: number;
};

type Actions = {
  setLang: (lang: Lang) => void;
  confirmAdult: () => void;
  saveProfile: (profile: Profile) => void;
  setFilters: (patch: Partial<Filters>) => void;
  openTab: (tab: Tab) => void;
  pass: (id: string) => void;
  like: (id: string) => LikeResult;
  block: (id: string) => void;
  report: (id: string, reason: string) => void;
  resetPasses: () => void;
  buy: (id: ProductId) => void;
  sendMessage: (id: string, text: string) => void;
  deleteAccount: () => void;
};

const fresh = (): State => ({
  lang: null,
  adult: false,
  profile: null,
  likes: [],
  passes: [],
  matches: [],
  blocked: [],
  reports: [],
  premiumUntil: null,
  extraLikes: 0,
  likesUsedToday: 0,
  likeDay: "",
  boostedUntil: null,
  messages: {},
  filters: { ageMin: 18, ageMax: 45, goal: "any", sameCountry: false },
  tab: "discover",
  seenMatchCount: 0,
});

export function dayKey(now = Date.now()) {
  const d = new Date(now);
  const month = `${d.getMonth() + 1}`.padStart(2, "0");
  const day = `${d.getDate()}`.padStart(2, "0");
  return `${d.getFullYear()}-${month}-${day}`;
}

export function isPremium(s: { premiumUntil: number | null }, now = Date.now()) {
  return s.premiumUntil != null && s.premiumUntil > now;
}

export function likeBudget(
  s: Pick<State, "premiumUntil" | "likeDay" | "likesUsedToday" | "extraLikes">,
  now = Date.now(),
) {
  const used = s.likeDay === dayKey(now) ? s.likesUsedToday : 0;
  const cap = isPremium(s, now) ? PREMIUM_CAP : FREE_CAP;
  const dailyLeft = Math.max(0, cap - used);
  return { cap, dailyLeft, extra: s.extraLikes, total: dailyLeft + s.extraLikes };
}

function clampAge(n: number) {
  return Math.min(80, Math.max(18, n));
}

export const useLoveStore = create<State & Actions>()(
  persist(
    (set, get) => ({
      ...fresh(),
      setLang: (lang) => set({ lang }),
      confirmAdult: () => set({ adult: true }),
      saveProfile: (profile) => set({ profile, tab: "discover" }),
      setFilters: (patch) =>
        set((s) => {
          let ageMin = clampAge(patch.ageMin ?? s.filters.ageMin);
          let ageMax = clampAge(patch.ageMax ?? s.filters.ageMax);
          if (ageMin > ageMax) {
            if (patch.ageMin != null) ageMax = ageMin;
            else ageMin = ageMax;
          }
          return { filters: { ...s.filters, ...patch, ageMin, ageMax } };
        }),
      openTab: (tab) =>
        set((s) => ({
          tab,
          seenMatchCount: tab === "matches" ? s.matches.length : s.seenMatchCount,
        })),
      pass: (id) =>
        set((s) => {
          if (s.passes.includes(id) || s.likes.includes(id) || s.blocked.includes(id)) return s;
          return { passes: [...s.passes, id] };
        }),
      like: (id) => {
        const s = get();
        if (s.likes.includes(id) || s.passes.includes(id) || s.blocked.includes(id)) {
          return { ok: false, reason: "seen" };
        }
        const now = Date.now();
        const day = dayKey(now);
        const used = s.likeDay === day ? s.likesUsedToday : 0;
        const cap = isPremium(s, now) ? PREMIUM_CAP : FREE_CAP;
        let likesUsedToday = used;
        let extraLikes = s.extraLikes;
        if (used < cap) likesUsedToday = used + 1;
        else if (extraLikes > 0) extraLikes -= 1;
        else return { ok: false, reason: "limit" };
        const person = findPerson(id);
        const matched = Boolean(person?.likedYou);
        const messages = { ...s.messages };
        if (matched && person) {
          messages[id] = [{ from: "them", text: person.hello[s.lang ?? "uk"], at: now }];
        }
        set({
          likes: [...s.likes, id],
          matches: matched ? [...s.matches, id] : s.matches,
          messages,
          likesUsedToday,
          extraLikes,
          likeDay: day,
        });
        return { ok: true, matched };
      },
      block: (id) =>
        set((s) => ({
          blocked: s.blocked.includes(id) ? s.blocked : [...s.blocked, id],
        })),
      report: (id, reason) =>
        set((s) => ({
          reports: [...s.reports, { id, reason, at: Date.now() }],
          blocked: s.blocked.includes(id) ? s.blocked : [...s.blocked, id],
        })),
      resetPasses: () => set({ passes: [] }),
      buy: (id) =>
        set((s) => {
          const now = Date.now();
          if (id === "likes10") return { extraLikes: s.extraLikes + 10 };
          if (id === "boost") return { boostedUntil: now + 30 * 60 * 1000 };
          const days = id === "week" ? 7 : 30;
          const base = Math.max(now, s.premiumUntil ?? 0);
          return { premiumUntil: base + days * 24 * 60 * 60 * 1000 };
        }),
      sendMessage: (id, text) => {
        const clean = text.trim().slice(0, 500);
        if (!clean) return;
        const s = get();
        const prev = s.messages[id] ?? [];
        const mine = prev.filter((m) => m.from === "me").length;
        set({
          messages: {
            ...s.messages,
            [id]: [...prev, { from: "me", text: clean, at: Date.now() }],
          },
        });
        if (mine > 0) return;
        const person = findPerson(id);
        if (!person) return;
        const reply = person.reply[s.lang ?? "uk"];
        window.setTimeout(() => {
          const cur = get();
          if (cur.blocked.includes(id)) return;
          const thread = cur.messages[id] ?? [];
          if (thread.some((m) => m.text === reply)) return;
          set({
            messages: {
              ...get().messages,
              [id]: [...(get().messages[id] ?? []), { from: "them", text: reply, at: Date.now() }],
            },
          });
        }, 800);
      },
      deleteAccount: () => set(fresh()),
    }),
    {
      name: "lovestar-v1",
      skipHydration: true,
      partialize: (s) => ({
        lang: s.lang,
        adult: s.adult,
        profile: s.profile,
        likes: s.likes,
        passes: s.passes,
        matches: s.matches,
        blocked: s.blocked,
        reports: s.reports,
        premiumUntil: s.premiumUntil,
        extraLikes: s.extraLikes,
        likesUsedToday: s.likesUsedToday,
        likeDay: s.likeDay,
        boostedUntil: s.boostedUntil,
        messages: s.messages,
        filters: s.filters,
        tab: s.tab,
        seenMatchCount: s.seenMatchCount,
      }),
    },
  ),
);
