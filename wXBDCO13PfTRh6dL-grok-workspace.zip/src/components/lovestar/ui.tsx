import type { ReactNode } from "react";
import { useEffect } from "react";
import { X } from "lucide-react";

const TOPS = ["top-8", "top-12", "top-16", "top-20"] as const;

export function StarMark({ className }: { className?: string }) {
  return (
    <svg viewBox="0 0 24 24" className={className} aria-hidden="true">
      <path
        fill="currentColor"
        d="M12 2.2 14.7 8.8 21.6 9.4 16.3 14.1 17.9 21 12 17.4 6.1 21 7.7 14.1 2.4 9.4 9.3 8.8Z"
      />
    </svg>
  );
}

export function Portrait({ name, className }: { name: string; className?: string }) {
  const letter = name.slice(0, 1).toUpperCase();
  const top = TOPS[name.length % TOPS.length];
  const marks = (name.charCodeAt(0) % 3) + 1;
  return (
    <div className={"night relative overflow-hidden " + (className ?? "")}>
      <span className="initial pointer-events-none absolute -left-1 top-1">{letter}</span>
      <div className={"hairline absolute inset-x-5 h-px " + top} />
      <div className="absolute bottom-4 left-4 flex gap-1 text-gold">
        {Array.from({ length: marks }, (_, i) => (
          <StarMark key={i} className="size-3" />
        ))}
      </div>
    </div>
  );
}

export function Sheet({
  open,
  title,
  closeLabel,
  onClose,
  children,
}: {
  open: boolean;
  title: string;
  closeLabel: string;
  onClose: () => void;
  children: ReactNode;
}) {
  useEffect(() => {
    if (!open) return;
    const onKey = (e: KeyboardEvent) => {
      if (e.key === "Escape") onClose();
    };
    window.addEventListener("keydown", onKey);
    return () => window.removeEventListener("keydown", onKey);
  }, [open, onClose]);
  if (!open) return null;
  return (
    <div className="absolute inset-0 z-30 flex flex-col justify-end">
      <button type="button" className="absolute inset-0 bg-bg/70" aria-label={closeLabel} onClick={onClose} />
      <div
        role="dialog"
        aria-modal="true"
        aria-label={title}
        className="relative max-h-[86%] overflow-y-auto rounded-t-4xl border border-line bg-surface px-5 pt-4 pb-6"
      >
        <div className="mb-4 flex items-center justify-between gap-3">
          <h2 className="font-display text-2xl">{title}</h2>
          <button
            type="button"
            className="grid size-11 place-items-center rounded-full border border-line text-fg"
            onClick={onClose}
            aria-label={closeLabel}
          >
            <X className="size-5" />
          </button>
        </div>
        {children}
      </div>
    </div>
  );
}

export function Chip({
  on,
  children,
  onClick,
}: {
  on: boolean;
  children: ReactNode;
  onClick: () => void;
}) {
  return (
    <button
      type="button"
      aria-pressed={on}
      onClick={onClick}
      className={
        "min-h-11 rounded-full border px-4 text-sm " +
        (on ? "border-gold bg-gold text-ink" : "border-line bg-raised text-fg")
      }
    >
      {children}
    </button>
  );
}

export function GoldButton({
  children,
  onClick,
  type = "button",
}: {
  children: ReactNode;
  onClick?: () => void;
  type?: "button" | "submit";
}) {
  return (
    <button
      type={type}
      onClick={onClick}
      className="min-h-12 w-full rounded-full bg-gold px-5 font-medium text-ink"
    >
      {children}
    </button>
  );
}
