import { useEffect, useState } from "react";
import { Compass, Heart, Star, UserRound } from "lucide-react";
import { copy } from "@/lib/lovestar/copy";
import { findPerson } from "@/lib/lovestar/people";
import { useLoveStore } from "@/lib/lovestar/store";
import type { Tab } from "@/lib/lovestar/types";
import { Discover } from "./discover";
import { Age, Language, Wizard } from "./gates";
import { Me } from "./me";
import { Chat, Matches } from "./matches";
import { Premium } from "./premium";
import { GoldButton, Portrait, StarMark } from "./ui";

export function LoveStar() {
  useEffect(() => {
    void useLoveStore.persist.rehydrate();
  }, []);
  return <Frame />;
}

function Frame() {
  const lang = useLoveStore((s) => s.lang);
  const adult = useLoveStore((s) => s.adult);
  const profile = useLoveStore((s) => s.profile);
  const [editing, setEditing] = useState(false);
  const t = copy[lang ?? "uk"];

  useEffect(() => {
    if (!profile) setEditing(false);
  }, [profile]);

  let screen;
  if (!lang) screen = <Language />;
  else if (!adult) screen = <Age />;
  else if (!profile || editing) screen = <Wizard editing={Boolean(profile) && editing} onCancel={() => setEditing(false)} />;
  else screen = <Main onEdit={() => setEditing(true)} />;

  return (
    <main className="h-dvh overflow-hidden bg-bg text-fg lg:grid lg:grid-cols-[minmax(0,1fr)_minmax(22rem,28rem)]">
      <aside className="hidden h-dvh flex-col justify-center px-10 lg:flex">
        <div className="ml-auto w-full max-w-md">
          <p className="text-sm tracking-wide text-gold">
            {t.brandKicker} · {t.adultMark}
          </p>
          <div className="mt-4 flex items-center gap-3">
            <StarMark className="size-8 text-gold" />
            <p className="font-display text-3xl">LOVE STAR</p>
          </div>
          <h1 className="mt-5 font-display text-4xl">{t.brandTitle}</h1>
          <p className="mt-3 max-w-sm text-muted">{t.brandBody}</p>
          <ul className="mt-6 grid gap-3 text-sm">
            {[t.pointSearch, t.pointMatch, t.pointStars].map((point) => (
              <li key={point} className="flex items-center gap-3">
                <StarMark className="size-4 shrink-0 text-gold" />
                <span>{point}</span>
              </li>
            ))}
          </ul>
        </div>
      </aside>
      <div className="h-dvh lg:p-3">
        <div className="device relative mx-auto flex h-full w-full max-w-lg flex-col overflow-hidden bg-bg lg:rounded-4xl lg:border lg:border-line">
          {screen}
        </div>
      </div>
    </main>
  );
}

function Main({ onEdit }: { onEdit: () => void }) {
  const lang = useLoveStore((s) => s.lang) ?? "uk";
  const t = copy[lang];
  const tab = useLoveStore((s) => s.tab);
  const openTab = useLoveStore((s) => s.openTab);
  const matches = useLoveStore((s) => s.matches);
  const seen = useLoveStore((s) => s.seenMatchCount);
  const [chatId, setChatId] = useState<string | null>(null);
  const [matchId, setMatchId] = useState<string | null>(null);
  const [toast, setToast] = useState<string | null>(null);
  const badge = Math.max(0, matches.length - seen);
  const matched = matchId ? findPerson(matchId) : undefined;

  function notify(message: string) {
    setToast(message);
    window.setTimeout(() => setToast(null), 2400);
  }

  const tabs: { id: Tab; label: string; icon: typeof Compass }[] = [
    { id: "discover", label: t.discover, icon: Compass },
    { id: "matches", label: t.matchesTab, icon: Heart },
    { id: "premium", label: t.premium, icon: Star },
    { id: "me", label: t.me, icon: UserRound },
  ];

  return (
    <div className="relative flex h-full min-h-0 flex-col">
      {chatId ? (
        <Chat id={chatId} onBack={() => setChatId(null)} />
      ) : (
        <>
          <div className="relative min-h-0 flex-1">
            {tab === "discover" ? (
              <Discover onMatch={setMatchId} onNotify={notify} onGoPremium={() => openTab("premium")} />
            ) : null}
            {tab === "matches" ? (
              <Matches
                onOpen={setChatId}
                onMatch={(id) => {
                  setMatchId(id);
                }}
                onGoPremium={() => openTab("premium")}
              />
            ) : null}
            {tab === "premium" ? <Premium onNotify={notify} /> : null}
            {tab === "me" ? <Me onEdit={onEdit} /> : null}
          </div>
          <nav className="safe-b grid grid-cols-4 border-t border-line bg-surface">
            {tabs.map((item) => {
              const Icon = item.icon;
              const active = tab === item.id;
              return (
                <button
                  key={item.id}
                  type="button"
                  aria-current={active ? "page" : undefined}
                  className={"flex min-h-16 flex-col items-center justify-center gap-1 text-xs " + (active ? "text-gold" : "text-muted")}
                  onClick={() => openTab(item.id)}
                >
                  <span className="relative">
                    <Icon className="size-5" />
                    {item.id === "matches" && badge > 0 ? (
                      <span className="absolute -top-2 -right-3 grid min-h-5 min-w-5 place-items-center rounded-full bg-gold px-1 text-ink tabular-nums">
                        {badge}
                      </span>
                    ) : null}
                  </span>
                  {item.label}
                </button>
              );
            })}
          </nav>
        </>
      )}
      {matched ? (
        <div className="absolute inset-0 z-40 flex flex-col justify-end bg-bg/80 p-5">
          <div className="rounded-4xl border border-line bg-surface px-5 py-6">
            <Portrait name={matched.name} className="mx-auto h-36 w-full rounded-3xl" />
            <h2 className="mt-4 text-center font-display text-4xl">{t.matchTitle}</h2>
            <p className="mt-2 text-center text-muted">
              {matched.name}. {t.matchBody}
            </p>
            <div className="mt-5 grid gap-3">
              <GoldButton
                onClick={() => {
                  openTab("matches");
                  setChatId(matched.id);
                  setMatchId(null);
                }}
              >
                {t.sayHi}
              </GoldButton>
              <button type="button" className="min-h-12 rounded-full border border-line" onClick={() => setMatchId(null)}>
                {t.keepLooking}
              </button>
            </div>
          </div>
        </div>
      ) : null}
      {toast ? (
        <p className="pointer-events-none absolute inset-x-4 top-4 z-50 rounded-full border border-line bg-raised px-4 py-3 text-center text-sm">
          {toast}
        </p>
      ) : null}
    </div>
  );
}
