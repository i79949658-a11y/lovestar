import { useEffect, useRef, useState } from "react";
import { ChevronLeft, Lock, Send } from "lucide-react";
import { copy, placeLine } from "@/lib/lovestar/copy";
import { findPerson, selectPeople, type Person } from "@/lib/lovestar/people";
import { isPremium, likeBudget, useLoveStore } from "@/lib/lovestar/store";
import { Portrait } from "./ui";

export function Matches({
  onOpen,
  onMatch,
  onGoPremium,
}: {
  onOpen: (id: string) => void;
  onMatch: (id: string) => void;
  onGoPremium: () => void;
}) {
  const lang = useLoveStore((s) => s.lang) ?? "uk";
  const t = copy[lang];
  const profile = useLoveStore((s) => s.profile);
  const filters = useLoveStore((s) => s.filters);
  const likes = useLoveStore((s) => s.likes);
  const passes = useLoveStore((s) => s.passes);
  const blocked = useLoveStore((s) => s.blocked);
  const matches = useLoveStore((s) => s.matches);
  const like = useLoveStore((s) => s.like);
  const premium = useLoveStore((s) => isPremium(s));
  const liked = selectPeople({ profile, filters, likes, passes, blocked }, "liked");
  const rows = matches
    .map((id) => findPerson(id))
    .filter((person) => person && !blocked.includes(person.id));

  function take(id: string) {
    if (likeBudget(useLoveStore.getState()).total < 1) {
      onGoPremium();
      return;
    }
    const res = like(id);
    if (!res.ok) {
      onGoPremium();
      return;
    }
    if (res.matched) onMatch(id);
  }

  return (
    <div className="flex h-full min-h-0 flex-col">
      <header className="px-5 pt-5 pb-3">
        <h1 className="font-display text-3xl">{t.matchesTab}</h1>
      </header>
      <div className="min-h-0 flex-1 overflow-y-auto px-5 pb-4">
        {liked.length > 0 ? (
          <section>
            <div className="mb-2 flex items-center justify-between gap-2">
              <h2 className="text-sm text-muted">{t.likesYou}</h2>
              {!premium ? <Lock className="size-4 text-gold" /> : null}
            </div>
            {!premium ? <p className="mb-3 text-sm text-muted">{t.likesYouLocked}</p> : null}
            <div className="flex gap-3 overflow-x-auto pb-2">
              {liked.map((person) => (
                <button
                  key={person.id}
                  type="button"
                  className="w-28 shrink-0 text-left"
                  aria-label={premium ? `${person.name}, ${person.age}` : t.someone}
                  onClick={() => (premium ? take(person.id) : onGoPremium())}
                >
                  <div className="relative h-36 overflow-hidden rounded-2xl">
                    <Portrait name={person.name} className={"h-full " + (premium ? "" : "blur-md")} />
                    {!premium ? (
                      <span className="absolute inset-0 grid place-items-center text-gold">
                        <Lock className="size-5" />
                      </span>
                    ) : null}
                  </div>
                  <p className="mt-2 truncate text-sm">{premium ? `${person.name}, ${person.age}` : t.someone}</p>
                </button>
              ))}
            </div>
          </section>
        ) : null}
        <section className="mt-4 grid gap-2">
          {rows.length === 0 ? (
            <div className="rounded-3xl border border-line bg-surface px-4 py-6">
              <h2 className="font-display text-2xl">{t.noMatches}</h2>
              <p className="mt-2 text-sm text-muted">{t.noMatchesBody}</p>
            </div>
          ) : (
            rows.map((person) =>
              person ? (
                <button
                  key={person.id}
                  type="button"
                  className="flex min-h-16 items-center gap-3 rounded-2xl border border-line bg-surface px-3 text-left"
                  onClick={() => onOpen(person.id)}
                >
                  <Portrait name={person.name} className="size-12 shrink-0 rounded-full" />
                  <span>
                    <span className="block font-medium">{person.name}</span>
                    <span className="block text-sm text-muted">{placeLine(t, person.country, person.city)}</span>
                  </span>
                </button>
              ) : null,
            )
          )}
        </section>
      </div>
    </div>
  );
}

export function Chat({ id, onBack }: { id: string; onBack: () => void }) {
  const lang = useLoveStore((s) => s.lang) ?? "uk";
  const t = copy[lang];
  const person = findPerson(id);
  const NONE: { from: "me" | "them"; text: string; at: number }[] = [];
  const messages = useLoveStore((s) => s.messages[id] ?? NONE);
  const sendMessage = useLoveStore((s) => s.sendMessage);
  const [text, setText] = useState("");
  const endRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    endRef.current?.scrollIntoView({ block: "end" });
  }, [messages.length]);

  if (!person) return null;

  function send() {
    sendMessage(id, text);
    setText("");
  }

  return (
    <div className="flex h-full min-h-0 flex-col">
      <header className="flex items-center gap-2 border-b border-line px-3 py-3">
        <button type="button" className="grid size-11 place-items-center" aria-label={t.back} onClick={onBack}>
          <ChevronLeft className="size-6" />
        </button>
        <Portrait name={person.name} className="size-11 rounded-full" />
        <div>
          <p className="font-medium">{person.name}</p>
          <p className="text-xs text-muted">{placeLine(t, person.country, person.city)}</p>
        </div>
      </header>
      <div className="min-h-0 flex-1 space-y-2 overflow-y-auto px-4 py-4">
        {messages.map((msg, i) => (
          <p
            key={msg.at + "-" + i}
            className={
              "bubble rounded-3xl px-4 py-2 text-sm " +
              (msg.from === "me" ? "ml-auto bg-gold text-ink" : "bg-raised text-fg")
            }
          >
            {msg.text}
          </p>
        ))}
        <div ref={endRef} />
      </div>
      <p className="px-4 text-xs text-muted">{t.chatNote}</p>
      <form
        className="flex items-center gap-2 px-3 py-3"
        onSubmit={(e) => {
          e.preventDefault();
          send();
        }}
      >
        <input
          className="h-12 min-w-0 flex-1 rounded-full border border-line bg-raised px-4 outline-none"
          value={text}
          placeholder={t.write}
          maxLength={500}
          onChange={(e) => setText(e.target.value)}
        />
        <button type="submit" className="grid size-12 place-items-center rounded-full bg-gold text-ink" aria-label={t.send}>
          <Send className="size-5" />
        </button>
      </form>
    </div>
  );
}
