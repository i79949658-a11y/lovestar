import { useState } from "react";
import { Shield } from "lucide-react";
import { ageWords, cityName, copy, interestName, placeLine } from "@/lib/lovestar/copy";
import { CITIES, COUNTRY_IDS, INTEREST_IDS } from "@/lib/lovestar/people";
import { useLoveStore } from "@/lib/lovestar/store";
import type { Goal, Looking, Profile } from "@/lib/lovestar/types";
import { Chip, GoldButton, Portrait, StarMark } from "./ui";

const NAME = /^[\p{L}][\p{L}\s'’.-]{1,23}$/u;
const LINK = /https?:\/\/|www\.|t\.me\/|@\w/i;

const field = "h-12 w-full rounded-2xl border border-line bg-raised px-4 text-fg outline-none";

export function Language() {
  const setLang = useLoveStore((s) => s.setLang);
  const t = copy.uk;
  return (
    <div className="flex h-full flex-col justify-between px-6 py-8">
      <div>
        <StarMark className="size-8 text-gold" />
        <p className="mt-6 text-sm tracking-wide text-gold">{t.adultMark}</p>
        <h1 className="mt-3 font-display text-4xl">LOVE STAR</h1>
        <p className="mt-3 text-muted">{t.langLead}</p>
      </div>
      <div>
        <p className="mb-3 text-sm text-muted">{t.chooseLang}</p>
        <div className="grid gap-3">
          <GoldButton onClick={() => setLang("uk")}>Українська</GoldButton>
          <button
            type="button"
            className="min-h-12 w-full rounded-full border border-line text-fg"
            onClick={() => setLang("en")}
          >
            English
          </button>
        </div>
      </div>
    </div>
  );
}

export function Age() {
  const lang = useLoveStore((s) => s.lang) ?? "uk";
  const confirmAdult = useLoveStore((s) => s.confirmAdult);
  const t = copy[lang];
  const [blocked, setBlocked] = useState(false);
  return (
    <div className="flex h-full flex-col px-6 py-8">
      <Shield className="size-8 text-gold" />
      <h1 className="mt-6 font-display text-4xl">{t.ageTitle}</h1>
      <p className="mt-3 text-muted">{blocked ? t.ageBlocked : t.ageBody}</p>
      <div className="mt-auto grid gap-3">
        {blocked ? (
          <button
            type="button"
            className="min-h-12 rounded-full border border-line"
            onClick={() => setBlocked(false)}
          >
            {t.back}
          </button>
        ) : (
          <>
            <GoldButton onClick={() => confirmAdult()}>{t.ageYes}</GoldButton>
            <button
              type="button"
              className="min-h-12 rounded-full border border-line"
              onClick={() => setBlocked(true)}
            >
              {t.ageNo}
            </button>
          </>
        )}
      </div>
    </div>
  );
}

type Draft = {
  name: string;
  age: string;
  country: string;
  city: string;
  looking: Looking;
  goal: Goal | null;
  interests: string[];
  bio: string;
};

export function Wizard({ editing, onCancel }: { editing: boolean; onCancel: () => void }) {
  const lang = useLoveStore((s) => s.lang) ?? "uk";
  const profile = useLoveStore((s) => s.profile);
  const saveProfile = useLoveStore((s) => s.saveProfile);
  const t = copy[lang];
  const [step, setStep] = useState(0);
  const [error, setError] = useState<string | null>(null);
  const [draft, setDraft] = useState<Draft>(() => ({
    name: profile?.name ?? "",
    age: profile ? String(profile.age) : "",
    country: profile?.country ?? "ua",
    city: profile?.city ?? "kyiv",
    looking: profile?.looking ?? "everyone",
    goal: profile?.goal ?? null,
    interests: profile?.interests ?? [],
    bio: profile?.bio ?? "",
  }));

  function citiesFor(country: string) {
    return CITIES[country] ?? [];
  }

  function problem(at: number): string | null {
    if (at === 0 && !NAME.test(draft.name.trim())) return t.errName;
    if (at === 1) {
      const n = Number(draft.age);
      if (!Number.isInteger(n) || n < 18 || n > 80) return t.errAge;
    }
    if (at === 4 && !draft.goal) return t.errGoal;
    if (at === 5 && (draft.interests.length < 2 || draft.interests.length > 5)) return t.errInterests;
    if (at === 6) {
      const bio = draft.bio.trim();
      if (LINK.test(bio)) return t.errLinks;
      if (bio.length < 20 || bio.length > 280) return t.errBio;
    }
    return null;
  }

  function publish() {
    for (const at of [0, 1, 4, 5, 6]) {
      const message = problem(at);
      if (message) {
        setStep(at);
        setError(message);
        return;
      }
    }
    if (!draft.goal) return;
    const next: Profile = {
      name: draft.name.trim(),
      age: Number(draft.age),
      country: draft.country,
      city: draft.city,
      looking: draft.looking,
      goal: draft.goal,
      interests: draft.interests,
      bio: draft.bio.trim(),
    };
    saveProfile(next);
    onCancel();
  }

  function forward() {
    const message = problem(step);
    if (message) {
      setError(message);
      return;
    }
    setError(null);
    if (step === 7) publish();
    else setStep((n) => n + 1);
  }

  function toggleInterest(id: string) {
    setDraft((d) => {
      const has = d.interests.includes(id);
      if (has) return { ...d, interests: d.interests.filter((item) => item !== id) };
      if (d.interests.length >= 5) return d;
      return { ...d, interests: [...d.interests, id] };
    });
    setError(null);
  }

  const titles = [
    t.stepName,
    t.stepAge,
    t.stepPlace,
    t.stepLook,
    t.stepGoal,
    t.stepInterests,
    t.stepBio,
    t.stepReview,
  ];
  const hints = [
    t.stepNameHint,
    t.stepAgeHint,
    t.stepPlaceHint,
    "",
    "",
    t.stepInterestsHint,
    t.stepBioHint,
    "",
  ];

  return (
    <div className="flex h-full flex-col">
      <div className="px-5 pt-5">
        <p className="text-sm text-gold">
          {editing ? t.editTitle : `${t.step} ${step + 1} / 8`}
        </p>
        <div className="mt-3 flex gap-1">
          {titles.map((_, i) => (
            <span key={i} className={"h-1 flex-1 rounded-full " + (i <= step ? "bg-gold" : "bg-line")} />
          ))}
        </div>
        <h1 className="mt-4 font-display text-3xl">{titles[step]}</h1>
        {hints[step] ? <p className="mt-2 text-sm text-muted">{hints[step]}</p> : null}
      </div>
      <div className="min-h-0 flex-1 overflow-y-auto px-5 py-4">
        {step === 0 && (
          <input
            className={field}
            value={draft.name}
            autoComplete="off"
            placeholder={t.namePh}
            onChange={(e) => {
              setDraft({ ...draft, name: e.target.value });
              setError(null);
            }}
          />
        )}
        {step === 1 && (
          <input
            className={field + " text-center font-display text-4xl"}
            inputMode="numeric"
            value={draft.age}
            placeholder="18"
            onChange={(e) => {
              setDraft({ ...draft, age: e.target.value.replace(/\D/g, "").slice(0, 2) });
              setError(null);
            }}
          />
        )}
        {step === 2 && (
          <div className="grid gap-3">
            <label className="grid gap-1 text-sm text-muted">
              {t.country}
              <select
                className={field}
                value={draft.country}
                onChange={(e) => {
                  const country = e.target.value;
                  const city = citiesFor(country)[0] ?? "";
                  setDraft({ ...draft, country, city });
                }}
              >
                {COUNTRY_IDS.map((id) => (
                  <option key={id} value={id}>
                    {t.countries[id]}
                  </option>
                ))}
              </select>
            </label>
            <label className="grid gap-1 text-sm text-muted">
              {t.city}
              <select
                className={field}
                value={draft.city}
                onChange={(e) => setDraft({ ...draft, city: e.target.value })}
              >
                {citiesFor(draft.country).map((id) => (
                  <option key={id} value={id}>
                    {cityName(t, id)}
                  </option>
                ))}
              </select>
            </label>
          </div>
        )}
        {step === 3 && (
          <div className="flex flex-wrap gap-2">
            {(
              [
                ["women", t.lookingWomen],
                ["men", t.lookingMen],
                ["everyone", t.lookingAll],
              ] as const
            ).map(([id, label]) => (
              <Chip key={id} on={draft.looking === id} onClick={() => setDraft({ ...draft, looking: id })}>
                {label}
              </Chip>
            ))}
          </div>
        )}
        {step === 4 && (
          <div className="flex flex-wrap gap-2">
            {(Object.keys(t.goals) as Goal[]).map((id) => (
              <Chip key={id} on={draft.goal === id} onClick={() => { setDraft({ ...draft, goal: id }); setError(null); }}>
                {t.goals[id]}
              </Chip>
            ))}
          </div>
        )}
        {step === 5 && (
          <div className="flex flex-wrap gap-2">
            {INTEREST_IDS.map((id) => (
              <Chip key={id} on={draft.interests.includes(id)} onClick={() => toggleInterest(id)}>
                {interestName(t, id)}
              </Chip>
            ))}
          </div>
        )}
        {step === 6 && (
          <div>
            <textarea
              className="min-h-36 w-full rounded-2xl border border-line bg-raised px-4 py-3 outline-none"
              value={draft.bio}
              maxLength={280}
              placeholder={t.bioPh}
              onChange={(e) => {
                setDraft({ ...draft, bio: e.target.value });
                setError(null);
              }}
            />
            <p className="mt-2 text-right text-sm text-muted tabular-nums">{draft.bio.trim().length}/280</p>
          </div>
        )}
        {step === 7 && draft.goal && (
          <div className="grid gap-4">
            <Portrait name={draft.name || "L"} className="h-36 rounded-3xl" />
            <div>
              <p className="font-display text-3xl">{draft.name}</p>
              <p className="text-muted">{ageWords(Number(draft.age) || 0, lang)}</p>
              <p className="mt-1 text-sm">{placeLine(t, draft.country, draft.city)}</p>
            </div>
            <p className="text-sm text-muted">
              {t.lookingLabel}: {draft.looking === "women" ? t.lookingWomen : draft.looking === "men" ? t.lookingMen : t.lookingAll}
            </p>
            <p className="text-sm">{t.goals[draft.goal]}</p>
            <div className="flex flex-wrap gap-2">
              {draft.interests.map((id) => (
                <span key={id} className="rounded-full border border-line px-3 py-1 text-sm">
                  {interestName(t, id)}
                </span>
              ))}
            </div>
            <p>{draft.bio}</p>
            <p className="text-sm text-muted">{t.photoNote}</p>
          </div>
        )}
        {error ? <p className="mt-3 text-sm text-fg">{error}</p> : null}
      </div>
      <div className="grid grid-cols-2 gap-3 px-5 pb-5">
        <button
          type="button"
          className="min-h-12 rounded-full border border-line disabled:opacity-40"
          disabled={!editing && step === 0}
          onClick={() => {
            setError(null);
            if (step === 0) onCancel();
            else setStep((n) => n - 1);
          }}
        >
          {step === 0 ? t.cancel : t.back}
        </button>
        <GoldButton onClick={forward}>{step === 7 ? (editing ? t.save : t.publish) : t.next}</GoldButton>
      </div>
    </div>
  );
}
