import { useEffect, useRef, useState } from "react";
import { Flag, Heart, Info, Minus, Plus, SlidersHorizontal, X } from "lucide-react";
import { copy, goalText, interestName, placeLine } from "@/lib/lovestar/copy";
import { selectPeople, type Person } from "@/lib/lovestar/people";
import { likeBudget, useLoveStore } from "@/lib/lovestar/store";
import type { Goal } from "@/lib/lovestar/types";
import { GoldButton, Portrait, Sheet, StarMark } from "./ui";

const REASONS = ["spam", "fake", "harass", "other"] as const;

export function Discover({
  onMatch,
  onNotify,
  onGoPremium,
}: {
  onMatch: (id: string) => void;
  onNotify: (message: string) => void;
  onGoPremium: () => void;
}) {
  const lang = useLoveStore((s) => s.lang) ?? "uk";
  const t = copy[lang];
  const profile = useLoveStore((s) => s.profile);
  const filters = useLoveStore((s) => s.filters);
  const likes = useLoveStore((s) => s.likes);
  const passes = useLoveStore((s) => s.passes);
  const blocked = useLoveStore((s) => s.blocked);
  const pass = useLoveStore((s) => s.pass);
  const like = useLoveStore((s) => s.like);
  const report = useLoveStore((s) => s.report);
  const block = useLoveStore((s) => s.block);
  const resetPasses = useLoveStore((s) => s.resetPasses);
  const setFilters = useLoveStore((s) => s.setFilters);
  const extraLikes = useLoveStore((s) => s.extraLikes);
  const likesUsedToday = useLoveStore((s) => s.likesUsedToday);
  const likeDay = useLoveStore((s) => s.likeDay);
  const premiumUntil = useLoveStore((s) => s.premiumUntil);
  const budget = likeBudget({ extraLikes, likesUsedToday, likeDay, premiumUntil });
  const openTab = useLoveStore((s) => s.openTab);
  const deck = selectPeople({ profile, filters, likes, passes, blocked }, "deck");
  const top = deck[0];
  const next = deck[1];
  const [sheet, setSheet] = useState<null | "filters" | "details" | "paywall" | "report">(null);
  const [reason, setReason] = useState<(typeof REASONS)[number]>("spam");
  const keysLocked = sheet != null;

  useEffect(() => {
    const onKey = (e: KeyboardEvent) => {
      if (keysLocked) return;
      const tag = (e.target as HTMLElement | null)?.tagName;
      if (tag === "INPUT" || tag === "TEXTAREA" || tag === "SELECT") return;
      if (e.key === "ArrowLeft" && top) commit("pass");
      if (e.key === "ArrowRight" && top) commit("like");
    };
    window.addEventListener("keydown", onKey);
    return () => window.removeEventListener("keydown", onKey);
  });

  function commit(dir: "like" | "pass") {
    if (!top) return;
    if (dir === "pass") {
      pass(top.id);
      return;
    }
    if (likeBudget(useLoveStore.getState()).total < 1) {
      setSheet("paywall");
      return;
    }
    const res = like(top.id);
    if (!res.ok && res.reason === "limit") setSheet("paywall");
    if (res.ok && res.matched) onMatch(top.id);
  }

  const reasonLabel = {
    spam: t.reasonSpam,
    fake: t.reasonFake,
    harass: t.reasonHarass,
    other: t.reasonOther,
  };

  return (
    <div className="relative flex h-full min-h-0 flex-col">
      <header className="flex items-center justify-between px-4 pt-4 pb-2">
        <div className="flex items-center gap-2">
          <StarMark className="size-5 text-gold" />
          <span className="font-display text-lg">LOVE STAR</span>
        </div>
        <div className="flex items-center gap-2">
          <button
            type="button"
            className="min-h-11 rounded-full border border-line px-3 text-sm tabular-nums"
            onClick={() => openTab("premium")}
          >
            {budget.total} {t.today}
          </button>
          <button
            type="button"
            className="grid size-11 place-items-center rounded-full border border-line"
            aria-label={t.filters}
            onClick={() => setSheet("filters")}
          >
            <SlidersHorizontal className="size-5" />
          </button>
        </div>
      </header>
      <p className="px-4 pb-2 text-xs text-muted">{t.demoPeople}</p>
      <div className="relative mx-4 min-h-0 flex-1">
        {next ? (
          <div className="absolute inset-x-2 top-3 bottom-0 overflow-hidden rounded-4xl border border-line opacity-70">
            <Portrait name={next.name} className="h-full" />
          </div>
        ) : null}
        {top ? (
          <SwipeCard
            key={top.id}
            person={top}
            goal={goalText(t, top.goal)}
            place={placeLine(t, top.country, top.city)}
            canLike={budget.total > 0}
            onNeedLikes={() => setSheet("paywall")}
            onDone={(dir) => {
              if (dir === "pass") pass(top.id);
              else {
                const res = like(top.id);
                if (!res.ok && res.reason === "limit") setSheet("paywall");
                if (res.ok && res.matched) onMatch(top.id);
              }
            }}
          />
        ) : (
          <div className="flex h-full flex-col items-start justify-center rounded-4xl border border-line bg-surface px-5">
            <h2 className="font-display text-3xl">{t.emptyTitle}</h2>
            <p className="mt-2 text-muted">{passes.length ? t.emptyBody : t.allHidden}</p>
            <div className="mt-5 grid w-full gap-3">
              {passes.length > 0 ? <GoldButton onClick={() => resetPasses()}>{t.replay}</GoldButton> : null}
              <button type="button" className="min-h-12 rounded-full border border-line" onClick={() => setSheet("filters")}>
                {t.filters}
              </button>
            </div>
          </div>
        )}
      </div>
      <div className="flex items-center justify-center gap-4 px-4 py-3">
        <button
          type="button"
          className="grid size-14 place-items-center rounded-full border border-line bg-surface disabled:opacity-40"
          aria-label={t.pass}
          disabled={!top}
          onClick={() => commit("pass")}
        >
          <X className="size-6" />
        </button>
        <button
          type="button"
          className="grid size-12 place-items-center rounded-full border border-line bg-surface disabled:opacity-40"
          aria-label={t.details}
          disabled={!top}
          onClick={() => setSheet("details")}
        >
          <Info className="size-5" />
        </button>
        <button
          type="button"
          className="grid size-16 place-items-center rounded-full bg-gold text-ink disabled:opacity-40"
          aria-label={t.like}
          disabled={!top}
          onClick={() => commit("like")}
        >
          <Heart className="size-7" />
        </button>
      </div>
      {likes.length === 0 && passes.length === 0 && top ? (
        <p className="px-6 pb-2 text-center text-xs text-muted">{t.hintSwipe}</p>
      ) : null}
      <Sheet open={sheet === "filters"} title={t.filters} closeLabel={t.close} onClose={() => setSheet(null)}>
        <div className="grid gap-4">
          <Stepper label={t.ageFrom} value={filters.ageMin} onChange={(ageMin) => setFilters({ ageMin })} />
          <Stepper label={t.ageTo} value={filters.ageMax} onChange={(ageMax) => setFilters({ ageMax })} />
          <div className="flex flex-wrap gap-2">
            <FilterChip on={filters.goal === "any"} label={t.anyGoal} onClick={() => setFilters({ goal: "any" })} />
            {(Object.keys(t.goals) as Goal[]).map((id) => (
              <FilterChip key={id} on={filters.goal === id} label={t.goals[id]} onClick={() => setFilters({ goal: id })} />
            ))}
          </div>
          <button
            type="button"
            aria-pressed={filters.sameCountry}
            className={
              "min-h-11 rounded-full border px-4 text-sm " +
              (filters.sameCountry ? "border-gold bg-gold text-ink" : "border-line")
            }
            onClick={() => setFilters({ sameCountry: !filters.sameCountry })}
          >
            {t.sameCountry}
          </button>
          <GoldButton onClick={() => setSheet(null)}>{t.done}</GoldButton>
        </div>
      </Sheet>
      <Sheet open={sheet === "details" && Boolean(top)} title={t.about} closeLabel={t.close} onClose={() => setSheet(null)}>
        {top ? (
          <div className="grid gap-3">
            <p className="font-display text-3xl">
              {top.name} <span className="text-muted tabular-nums">{top.age}</span>
            </p>
            <p className="text-sm text-muted">{placeLine(t, top.country, top.city)}</p>
            <p>{goalText(t, top.goal)}</p>
            <p>{top.bio[lang]}</p>
            <div className="flex flex-wrap gap-2">
              {top.interests.map((id) => (
                <span key={id} className="rounded-full border border-line px-3 py-1 text-sm">
                  {interestName(t, id)}
                </span>
              ))}
            </div>
            <button
              type="button"
              className="flex min-h-12 items-center gap-2 rounded-2xl border border-line px-4"
              onClick={() => setSheet("report")}
            >
              <Flag className="size-4" /> {t.report}
            </button>
            <button
              type="button"
              className="flex min-h-12 items-center gap-2 rounded-2xl border border-line px-4"
              onClick={() => {
                block(top.id);
                setSheet(null);
                onNotify(t.blockedToast);
              }}
            >
              <X className="size-4" /> {t.block}
            </button>
          </div>
        ) : null}
      </Sheet>
      <Sheet open={sheet === "report"} title={t.reportTitle} closeLabel={t.close} onClose={() => setSheet(null)}>
        <div className="grid gap-2">
          {REASONS.map((id) => (
            <button
              key={id}
              type="button"
              aria-pressed={reason === id}
              className={
                "min-h-12 rounded-2xl border px-4 text-left " +
                (reason === id ? "border-gold bg-gold text-ink" : "border-line")
              }
              onClick={() => setReason(id)}
            >
              {reasonLabel[id]}
            </button>
          ))}
          <GoldButton
            onClick={() => {
              if (!top) return;
              report(top.id, reason);
              setSheet(null);
              onNotify(t.reported);
            }}
          >
            {t.sendReport}
          </GoldButton>
        </div>
      </Sheet>
      <Sheet open={sheet === "paywall"} title={t.limitTitle} closeLabel={t.close} onClose={() => setSheet(null)}>
        <p className="text-muted">{t.limitBody}</p>
        <div className="mt-4 grid gap-3">
          <GoldButton
            onClick={() => {
              setSheet(null);
              onGoPremium();
            }}
          >
            {t.seePremium}
          </GoldButton>
          <button type="button" className="min-h-12 rounded-full border border-line" onClick={() => setSheet(null)}>
            {t.later}
          </button>
        </div>
      </Sheet>
    </div>
  );
}

function FilterChip({ on, label, onClick }: { on: boolean; label: string; onClick: () => void }) {
  return (
    <button
      type="button"
      aria-pressed={on}
      onClick={onClick}
      className={"min-h-11 rounded-full border px-4 text-sm " + (on ? "border-gold bg-gold text-ink" : "border-line")}
    >
      {label}
    </button>
  );
}

function Stepper({ label, value, onChange }: { label: string; value: number; onChange: (n: number) => void }) {
  return (
    <div className="flex items-center justify-between gap-3">
      <span>{label}</span>
      <div className="flex items-center gap-2">
        <button
          type="button"
          className="grid size-11 place-items-center rounded-full border border-line"
          aria-label={label}
          onClick={() => onChange(value - 1)}
        >
          <Minus className="size-4" />
        </button>
        <span className="w-8 text-center tabular-nums">{value}</span>
        <button
          type="button"
          className="grid size-11 place-items-center rounded-full border border-line"
          aria-label={label}
          onClick={() => onChange(value + 1)}
        >
          <Plus className="size-4" />
        </button>
      </div>
    </div>
  );
}

function SwipeCard({
  person,
  place,
  goal,
  canLike,
  onNeedLikes,
  onDone,
}: {
  person: Person;
  place: string;
  goal: string;
  canLike: boolean;
  onNeedLikes: () => void;
  onDone: (dir: "like" | "pass") => void;
}) {
  const origin = useRef({ x: 0, y: 0 });
  const pointRef = useRef({ x: 0, y: 0, dragging: false });
  const [point, setPoint] = useState({ x: 0, y: 0, dragging: false });
  const gone = useRef(false);

  function move(nextPoint: { x: number; y: number; dragging: boolean }) {
    pointRef.current = nextPoint;
    setPoint(nextPoint);
  }

  function finish(dir: "like" | "pass") {
    if (gone.current) return;
    if (dir === "like" && !canLike) {
      onNeedLikes();
      move({ x: 0, y: 0, dragging: false });
      return;
    }
    gone.current = true;
    const reduced = window.matchMedia("(prefers-reduced-motion: reduce)").matches;
    move({ x: dir === "like" ? 520 : -520, y: 24, dragging: false });
    window.setTimeout(() => onDone(dir), reduced ? 0 : 200);
  }

  const likeStamp = Math.min(1, Math.max(0, point.x / 120));
  const passStamp = Math.min(1, Math.max(0, -point.x / 120));

  return (
    <article
      className="motion absolute inset-0 touch-none overflow-hidden rounded-4xl border border-line select-none"
      style={{
        transform: `translate3d(${point.x}px, ${point.y}px, 0) rotate(${point.x / 18}deg)`,
        transition: point.dragging ? "none" : "transform 200ms ease",
      }}
      onPointerDown={(e) => {
        if (gone.current) return;
        origin.current = { x: e.clientX, y: e.clientY };
        e.currentTarget.setPointerCapture(e.pointerId);
        move({ x: 0, y: 0, dragging: true });
      }}
      onPointerMove={(e) => {
        if (!pointRef.current.dragging || gone.current) return;
        move({
          x: e.clientX - origin.current.x,
          y: (e.clientY - origin.current.y) * 0.25,
          dragging: true,
        });
      }}
      onPointerUp={() => {
        const current = pointRef.current;
        if (!current.dragging || gone.current) return;
        if (current.x > 96) finish("like");
        else if (current.x < -96) finish("pass");
        else move({ x: 0, y: 0, dragging: false });
      }}
      onPointerCancel={() => move({ x: 0, y: 0, dragging: false })}
    >
      <Portrait name={person.name} className="absolute inset-0" />
      <div className="card-shade absolute inset-0" />
      {likeStamp > 0.08 ? (
        <div className="absolute top-8 left-5 rounded-2xl border border-gold px-3 py-1 text-gold" style={{ opacity: likeStamp }}>
          <Heart className="size-6" />
        </div>
      ) : null}
      {passStamp > 0.08 ? (
        <div className="absolute top-8 right-5 rounded-2xl border border-line px-3 py-1 text-fg" style={{ opacity: passStamp }}>
          <X className="size-6" />
        </div>
      ) : null}
      <div className="absolute inset-x-0 bottom-0 p-4">
        <div className="flex items-end gap-2">
          <h2 className="font-display text-4xl">{person.name}</h2>
          <span className="mb-1 text-xl text-muted tabular-nums">{person.age}</span>
        </div>
        <p className="mt-1 text-sm text-muted">{place}</p>
        <p className="mt-2 text-sm">{goal}</p>
      </div>
    </article>
  );
}
