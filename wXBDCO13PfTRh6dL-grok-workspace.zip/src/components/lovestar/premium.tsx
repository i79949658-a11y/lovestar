import { useState } from "react";
import { Star } from "lucide-react";
import { copy } from "@/lib/lovestar/copy";
import { isPremium, useLoveStore, type ProductId } from "@/lib/lovestar/store";
import { GoldButton, Sheet, StarMark } from "./ui";

const PRODUCTS: { id: ProductId; stars: number; title: "productLikes" | "productBoost" | "productWeek" | "productMonth"; body: "productLikesBody" | "productBoostBody" | "productWeekBody" | "productMonthBody" }[] = [
  { id: "likes10", stars: 29, title: "productLikes", body: "productLikesBody" },
  { id: "boost", stars: 25, title: "productBoost", body: "productBoostBody" },
  { id: "week", stars: 99, title: "productWeek", body: "productWeekBody" },
  { id: "month", stars: 249, title: "productMonth", body: "productMonthBody" },
];

function when(ts: number, lang: "uk" | "en", withTime = false) {
  return new Date(ts).toLocaleString(lang === "uk" ? "uk-UA" : "en-GB", {
    day: "numeric",
    month: "short",
    hour: withTime ? "2-digit" : undefined,
    minute: withTime ? "2-digit" : undefined,
  });
}

export function Premium({ onNotify }: { onNotify: (message: string) => void }) {
  const lang = useLoveStore((s) => s.lang) ?? "uk";
  const t = copy[lang];
  const premiumUntil = useLoveStore((s) => s.premiumUntil);
  const boostedUntil = useLoveStore((s) => s.boostedUntil);
  const buy = useLoveStore((s) => s.buy);
  const premium = isPremium({ premiumUntil });
  const [pick, setPick] = useState<(typeof PRODUCTS)[number] | null>(null);
  const perks = [t.perkLikes, t.perkSee, t.perkBoost, t.perkFilters];

  return (
    <div className="flex h-full min-h-0 flex-col">
      <div className="min-h-0 flex-1 overflow-y-auto px-5 pt-5 pb-4">
        <div className="flex items-center gap-2 text-gold">
          <StarMark className="size-5" />
          <p className="text-sm">{t.premium}</p>
        </div>
        <h1 className="mt-2 font-display text-4xl">LOVE STAR</h1>
        <p className="mt-2 text-muted">{t.premiumLead}</p>
        <p className="mt-4 rounded-2xl border border-line bg-surface px-4 py-3 text-sm">
          {premium && premiumUntil ? `${t.activeUntil} ${when(premiumUntil, lang)}` : t.freeNow}
          {boostedUntil && boostedUntil > Date.now() ? ` ${t.boostActive} ${when(boostedUntil, lang, true)}.` : ""}
        </p>
        <h2 className="mt-6 font-display text-2xl">{t.perksTitle}</h2>
        <ul className="mt-3 grid gap-2">
          {perks.map((perk) => (
            <li key={perk} className="flex items-start gap-2 text-sm">
              <Star className="mt-0.5 size-4 shrink-0 text-gold" />
              <span>{perk}</span>
            </li>
          ))}
        </ul>
        <div className="mt-6 grid gap-3">
          {PRODUCTS.map((product) => (
            <button
              key={product.id}
              type="button"
              className="rounded-3xl border border-line bg-raised px-4 py-4 text-left"
              onClick={() => setPick(product)}
            >
              <span className="flex items-center justify-between gap-3">
                <span className="font-medium">{t[product.title]}</span>
                <span className="flex items-center gap-1 text-gold tabular-nums">
                  {product.stars}
                  <StarMark className="size-3.5" />
                </span>
              </span>
              <span className="mt-1 block text-sm text-muted">{t[product.body]}</span>
            </button>
          ))}
        </div>
        <p className="mt-4 text-xs text-muted">{t.starsNote}</p>
      </div>
      <Sheet open={pick != null} title={pick ? t[pick.title] : t.premium} closeLabel={t.close} onClose={() => setPick(null)}>
        {pick ? (
          <div className="grid gap-4">
            <p className="text-muted">{t[pick.body]}</p>
            <p className="flex items-center gap-2 font-display text-4xl text-gold tabular-nums">
              {pick.stars}
              <StarMark className="size-7" />
            </p>
            <GoldButton
              onClick={() => {
                buy(pick.id);
                setPick(null);
                onNotify(t.purchased);
              }}
            >
              {t.getFor} {pick.stars}
            </GoldButton>
          </div>
        ) : null}
      </Sheet>
    </div>
  );
}
