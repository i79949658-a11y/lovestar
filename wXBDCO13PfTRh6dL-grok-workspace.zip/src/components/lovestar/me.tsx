import { useState } from "react";
import { ageWords, copy, interestName, placeLine } from "@/lib/lovestar/copy";
import { likeBudget, useLoveStore } from "@/lib/lovestar/store";
import { GoldButton, Portrait, Sheet } from "./ui";

export function Me({ onEdit }: { onEdit: () => void }) {
  const lang = useLoveStore((s) => s.lang) ?? "uk";
  const t = copy[lang];
  const profile = useLoveStore((s) => s.profile);
  const setLang = useLoveStore((s) => s.setLang);
  const boostedUntil = useLoveStore((s) => s.boostedUntil);
  const resetPasses = useLoveStore((s) => s.resetPasses);
  const deleteAccount = useLoveStore((s) => s.deleteAccount);
  const extraLikes = useLoveStore((s) => s.extraLikes);
  const likesUsedToday = useLoveStore((s) => s.likesUsedToday);
  const likeDay = useLoveStore((s) => s.likeDay);
  const premiumUntil = useLoveStore((s) => s.premiumUntil);
  const budget = likeBudget({ extraLikes, likesUsedToday, likeDay, premiumUntil });
  const passes = useLoveStore((s) => s.passes);
  const [confirm, setConfirm] = useState(false);
  if (!profile) return null;
  const boosted = boostedUntil != null && boostedUntil > Date.now();

  return (
    <div className="h-full overflow-y-auto px-5 pt-5 pb-6">
      <h1 className="font-display text-3xl">{t.yourProfile}</h1>
      <Portrait name={profile.name} className="mt-4 h-40 rounded-3xl" />
      <p className="mt-4 font-display text-3xl">{profile.name}</p>
      <p className="text-muted">{ageWords(profile.age, lang)}</p>
      <p className="mt-1 text-sm">{placeLine(t, profile.country, profile.city)}</p>
      <p className="mt-3 text-sm text-muted">
        {t.lookingLabel}: {profile.looking === "women" ? t.lookingWomen : profile.looking === "men" ? t.lookingMen : t.lookingAll}
      </p>
      <p className="mt-1 text-sm">{t.goals[profile.goal]}</p>
      <div className="mt-3 flex flex-wrap gap-2">
        {profile.interests.map((id) => (
          <span key={id} className="rounded-full border border-line px-3 py-1 text-sm">
            {interestName(t, id)}
          </span>
        ))}
      </div>
      <p className="mt-3">{profile.bio}</p>
      <p className="mt-3 text-sm text-muted">{t.photoNote}</p>
      <p className="mt-3 text-sm tabular-nums">
        {budget.total} {t.likesToday.toLowerCase()}
        {boosted && boostedUntil ? ` · ${t.boostedUntil} ${new Date(boostedUntil).toLocaleTimeString(lang === "uk" ? "uk-UA" : "en-GB", { hour: "2-digit", minute: "2-digit" })}` : ` · ${t.notBoosted}`}
      </p>
      <div className="mt-4">
        <GoldButton onClick={onEdit}>{t.editProfile}</GoldButton>
      </div>
      <section className="mt-6">
        <h2 className="text-sm text-muted">{t.language}</h2>
        <div className="mt-2 flex gap-2">
          <button
            type="button"
            aria-pressed={lang === "uk"}
            className={"min-h-11 rounded-full border px-4 " + (lang === "uk" ? "border-gold bg-gold text-ink" : "border-line")}
            onClick={() => setLang("uk")}
          >
            Українська
          </button>
          <button
            type="button"
            aria-pressed={lang === "en"}
            className={"min-h-11 rounded-full border px-4 " + (lang === "en" ? "border-gold bg-gold text-ink" : "border-line")}
            onClick={() => setLang("en")}
          >
            English
          </button>
        </div>
      </section>
      {passes.length > 0 ? (
        <button type="button" className="mt-4 min-h-11 text-sm text-gold" onClick={() => resetPasses()}>
          {t.replay}
        </button>
      ) : null}
      <section className="mt-6 rounded-3xl border border-line bg-surface px-4 py-4">
        <h2 className="font-display text-xl">{t.botTitle}</h2>
        <ul className="mt-2 grid gap-1 text-sm text-muted">
          <li>{t.botStart}</li>
          <li>{t.botNotify}</li>
          <li>{t.botPay}</li>
        </ul>
      </section>
      <section className="mt-3 rounded-3xl border border-line px-4 py-4">
        <h2 className="font-display text-xl">{t.privacy}</h2>
        <p className="mt-2 text-sm text-muted">{t.privacyBody}</p>
        <h2 className="mt-4 font-display text-xl">{t.safety}</h2>
        <p className="mt-2 text-sm text-muted">{t.safetyBody}</p>
      </section>
      <button type="button" className="mt-6 min-h-11 text-sm text-muted" onClick={() => setConfirm(true)}>
        {t.deleteAccount}
      </button>
      <Sheet open={confirm} title={t.deleteAccount} closeLabel={t.close} onClose={() => setConfirm(false)}>
        <p className="text-muted">{t.deleteBody}</p>
        <div className="mt-4 grid gap-3">
          <button
            type="button"
            className="min-h-12 rounded-full bg-gold text-ink"
            onClick={() => {
              setConfirm(false);
              deleteAccount();
            }}
          >
            {t.deleteConfirm}
          </button>
          <button type="button" className="min-h-12 rounded-full border border-line" onClick={() => setConfirm(false)}>
            {t.cancel}
          </button>
        </div>
      </Sheet>
    </div>
  );
}
