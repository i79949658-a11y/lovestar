import { createFileRoute } from "@tanstack/react-router";
import { LoveStar } from "@/components/lovestar/app";

export const Route = createFileRoute("/")({ component: Home });

function Home() {
  return <LoveStar />;
}
