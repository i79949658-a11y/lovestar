//#region node_modules/.nitro/vite/services/ssr/assets/_tanstack-start-manifest_v-C7GP0DYs.js
var tsrStartManifest = () => ({ routes: {
	__root__: {
		filePath: "/workspace/src/routes/__root.tsx",
		children: ["/"],
		preloads: ["/assets/index-Qc0u60OI.js"],
		scripts: [{ attrs: {
			type: "module",
			async: !0,
			src: "/assets/index-Qc0u60OI.js"
		} }]
	},
	"/": {
		filePath: "/workspace/src/routes/index.tsx",
		children: void 0,
		preloads: ["/assets/routes-D80ipk3L.js"]
	}
} });
//#endregion
export { tsrStartManifest };
