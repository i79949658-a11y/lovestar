import { i as __toESM } from "../_runtime.mjs";
import { K as require_react, b as require_jsx_runtime } from "../_libs/@tanstack/react-router+[...].mjs";
import { a as SlidersHorizontal, c as Plus, d as Info, f as Heart, h as ChevronLeft, i as Star, l as Minus, m as Compass, n as UserRound, o as Shield, p as Flag, s as Send, t as X, u as Lock } from "../_libs/lucide-react.mjs";
import { n as create, t as persist } from "../_libs/zustand.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/routes-fuerkzoL.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
var copy = {
	uk: {
		chooseLang: "Обери мову",
		langLead: "Міжнародні знайомства для дорослих. Анкета, лайки й взаємна симпатія.",
		ageTitle: "Тобі вже є 18?",
		ageBody: "LOVE STAR лише для повнолітніх. Натискаючи «Так», ти підтверджуєш, що тобі виповнилося 18 років.",
		ageYes: "Так, мені є 18",
		ageNo: "Ні, мені ще немає 18",
		ageBlocked: "Тоді ми не відкриємо сервіс. Повертайся, коли виповниться 18.",
		step: "Крок",
		stepName: "Як до тебе звертатися?",
		stepNameHint: "Ім’я або псевдонім. Прізвище не обов’язкове.",
		namePh: "Наприклад, Марія",
		stepAge: "Скільки тобі років?",
		stepAgeHint: "Інші побачать лише вік, не дату народження.",
		stepPlace: "Де ти зараз?",
		stepPlaceHint: "Країна й місто допомагають знаходити людей поруч.",
		country: "Країна",
		city: "Місто",
		stepLook: "Кого показувати?",
		stepGoal: "Навіщо тобі знайомства?",
		stepInterests: "Що тобі близьке?",
		stepInterestsHint: "Обери від двох до п’яти.",
		stepBio: "Коротко про себе",
		stepBioHint: "Без телефону, посилань і точної адреси.",
		bioPh: "Чим живеш і кого шукаєш",
		stepReview: "Переглянь анкету",
		publish: "Показати анкету",
		save: "Зберегти",
		next: "Далі",
		back: "Назад",
		cancel: "Скасувати",
		editTitle: "Редагування",
		errName: "Ім’я — від 2 до 24 літер.",
		errAge: "Вік має бути від 18 до 80.",
		errGoal: "Обери мету знайомства.",
		errBio: "Напиши від 20 до 280 символів.",
		errLinks: "Прибери посилання, @імена й адреси.",
		errInterests: "Обери щонайменше два інтереси.",
		lookingWomen: "Жінок",
		lookingMen: "Чоловіків",
		lookingAll: "Усіх",
		discover: "Пошук",
		matchesTab: "Збіги",
		premium: "Premium",
		me: "Профіль",
		demoPeople: "Демо-анкети. Твоя анкета лишається на цьому пристрої.",
		likesToday: "Лайків сьогодні",
		today: "сьогодні",
		pass: "Пропустити",
		like: "Подобається",
		details: "Деталі",
		filters: "Фільтри",
		ageFrom: "Вік від",
		ageTo: "Вік до",
		anyGoal: "Будь-яка мета",
		sameCountry: "Лише моя країна",
		done: "Готово",
		emptyTitle: "За цими фільтрами нікого немає",
		emptyBody: "Зміни фільтри або поверни людей, яких пропустив.",
		allHidden: "У цьому доборі більше нікого не видно.",
		replay: "Повернути пропущених",
		hintSwipe: "Проведи картку вбік або натисни серце.",
		limitTitle: "Лайки на сьогодні закінчились",
		limitBody: "Безкоштовно їх 8 на день. Premium дає 40, пакет додає ще 10.",
		seePremium: "Дивитись Premium",
		later: "Пізніше",
		matchTitle: "Це взаємно",
		matchBody: "Можна написати просто зараз. У боті про це прийде сповіщення.",
		sayHi: "Написати",
		keepLooking: "Шукати далі",
		report: "Поскаржитись",
		block: "Заблокувати",
		reportTitle: "Чому скаржишся?",
		reasonSpam: "Спам або реклама",
		reasonFake: "Фейкова анкета",
		reasonHarass: "Образлива поведінка",
		reasonOther: "Інше",
		sendReport: "Надіслати скаргу",
		reported: "Скаргу збережено, анкету приховано.",
		blockedToast: "Людину заблоковано й приховано.",
		about: "Про людину",
		close: "Закрити",
		likesYou: "Тебе лайкнули",
		likesYouLocked: "Імена відкриває Premium.",
		someone: "Хтось поруч",
		noMatches: "Поки немає взаємних",
		noMatchesBody: "Коли лайк взаємний, людина з’явиться тут.",
		write: "Напиши повідомлення",
		send: "Надіслати",
		chatNote: "У боті це прийде як сповіщення. Тут розмова лишається в прев’ю.",
		you: "Ти",
		premiumLead: "Більше лайків, хто вже лайкнув тебе, і підняття анкети.",
		starsNote: "У боті оплата йде через Telegram Stars. Тут покупка демонстраційна — нічого не списується.",
		perksTitle: "Що дає Premium",
		perkLikes: "40 лайків на день замість 8",
		perkSee: "Видно, хто поставив тобі лайк",
		perkBoost: "Підняття анкети окремим пакетом",
		perkFilters: "Фільтри за віком, країною та метою",
		activeUntil: "Premium до",
		freeNow: "Зараз базовий доступ: 8 лайків на день.",
		boostActive: "Анкету піднято до",
		productLikes: "10 додаткових лайків",
		productLikesBody: "Не згорають опівночі. Списуються, коли денний ліміт уже вичерпано.",
		productBoost: "Підняти анкету",
		productBoostBody: "Коротке просування. У прев’ю — на 30 хвилин.",
		productWeek: "Premium на 7 днів",
		productWeekBody: "Більше лайків і відкриті симпатії.",
		productMonth: "Premium на 30 днів",
		productMonthBody: "Той самий набір на довший строк.",
		getFor: "Отримати за",
		purchased: "Готово. У боті тут був би чек Stars.",
		yourProfile: "Твоя анкета",
		photoNote: "У боті сюди стає фото після модерації. У прев’ю анкета позначена зіркою.",
		boostedUntil: "Піднято до",
		notBoosted: "Зараз анкета у звичайній стрічці.",
		language: "Мова",
		privacy: "Приватність",
		privacyBody: "Інші бачать ім’я, вік, місто, інтереси й опис. Дату народження й точну адресу — ні.",
		safety: "Безпека",
		safetyBody: "Скарга або блок ховає людину з твоєї стрічки. У сервісі це йде в модерацію.",
		deleteAccount: "Видалити анкету з пристрою",
		deleteBody: "Прибере ім’я, опис, лайки й розмови з цього прев’ю.",
		deleteConfirm: "Видалити все",
		goalLabel: "Мета",
		lookingLabel: "Показувати",
		editProfile: "Редагувати анкету",
		botTitle: "Що робить бот",
		botStart: "Реєстрація й мова — команда /start",
		botNotify: "Сповіщення про лайки та збіги",
		botPay: "Рахунки Premium через Telegram Stars",
		brandKicker: "Mini App",
		brandTitle: "Знайомства, які починаються із зірки.",
		brandBody: "Анкета, лайки й взаємна симпатія. Сповіщення лишаються за ботом — тут ти дивишся людей.",
		pointSearch: "Пошук за віком, країною та метою",
		pointMatch: "Збіг лише коли лайк взаємний",
		pointStars: "Premium і пакети — через Stars",
		adultMark: "18+",
		goals: {
			serious: "Серйозні стосунки",
			dates: "Побачення",
			chat: "Спілкування",
			friends: "Дружба"
		},
		countries: {
			ua: "Україна",
			pl: "Польща",
			de: "Німеччина",
			es: "Іспанія",
			fr: "Франція",
			it: "Італія",
			jp: "Японія",
			nl: "Нідерланди",
			pt: "Португалія",
			gb: "Велика Британія",
			us: "США"
		},
		cities: {
			kyiv: "Київ",
			lviv: "Львів",
			odesa: "Одеса",
			dnipro: "Дніпро",
			warsaw: "Варшава",
			krakow: "Краків",
			berlin: "Берлін",
			munich: "Мюнхен",
			barcelona: "Барселона",
			madrid: "Мадрид",
			paris: "Париж",
			lyon: "Ліон",
			milan: "Мілан",
			rome: "Рим",
			tokyo: "Токіо",
			osaka: "Осака",
			amsterdam: "Амстердам",
			lisbon: "Лісабон",
			london: "Лондон",
			newyork: "Нью-Йорк"
		},
		interests: {
			music: "Музика",
			travel: "Подорожі",
			coffee: "Кава",
			sport: "Спорт",
			cinema: "Кіно",
			books: "Книжки",
			cooking: "Кухня",
			art: "Мистецтво",
			hiking: "Прогулянки",
			photo: "Фото",
			dance: "Танці",
			design: "Дизайн",
			food: "Їжа",
			languages: "Мови"
		}
	},
	en: {
		chooseLang: "Choose a language",
		langLead: "International dating for adults. A profile, likes, and a mutual spark.",
		ageTitle: "Are you 18 or older?",
		ageBody: "LOVE STAR is only for adults. By continuing you confirm that you are at least 18.",
		ageYes: "Yes, I am 18+",
		ageNo: "No, I am under 18",
		ageBlocked: "Then we can’t open the service. Come back when you turn 18.",
		step: "Step",
		stepName: "What should people call you?",
		stepNameHint: "A first name or nickname. A surname is optional.",
		namePh: "For example, Maria",
		stepAge: "How old are you?",
		stepAgeHint: "Others see your age, never a birth date.",
		stepPlace: "Where are you?",
		stepPlaceHint: "Country and city help you meet people nearby.",
		country: "Country",
		city: "City",
		stepLook: "Who should we show?",
		stepGoal: "What are you here for?",
		stepInterests: "What feels like you?",
		stepInterestsHint: "Pick two to five.",
		stepBio: "A short note",
		stepBioHint: "No phone numbers, links, or a precise address.",
		bioPh: "How you spend your days, and who you hope to meet",
		stepReview: "Review your profile",
		publish: "Publish profile",
		save: "Save",
		next: "Next",
		back: "Back",
		cancel: "Cancel",
		editTitle: "Edit profile",
		errName: "Use 2 to 24 letters.",
		errAge: "Age has to be from 18 to 80.",
		errGoal: "Choose what you’re looking for.",
		errBio: "Write between 20 and 280 characters.",
		errLinks: "Remove links, @handles, and addresses.",
		errInterests: "Pick at least two interests.",
		lookingWomen: "Women",
		lookingMen: "Men",
		lookingAll: "Everyone",
		discover: "Discover",
		matchesTab: "Matches",
		premium: "Premium",
		me: "Profile",
		demoPeople: "Demonstration profiles. Yours stays on this device.",
		likesToday: "Likes today",
		today: "today",
		pass: "Pass",
		like: "Like",
		details: "Details",
		filters: "Filters",
		ageFrom: "Age from",
		ageTo: "Age to",
		anyGoal: "Any intention",
		sameCountry: "Only my country",
		done: "Done",
		emptyTitle: "No one matches these filters",
		emptyBody: "Change the filters, or bring back people you passed.",
		allHidden: "No one else is visible in this set.",
		replay: "Bring back passes",
		hintSwipe: "Drag a card, or tap the heart.",
		limitTitle: "No likes left today",
		limitBody: "Free accounts get 8 a day. Premium gets 40, and a pack adds 10.",
		seePremium: "See Premium",
		later: "Not now",
		matchTitle: "It’s mutual",
		matchBody: "You can write now. In the bot, this arrives as a notification.",
		sayHi: "Say hello",
		keepLooking: "Keep looking",
		report: "Report",
		block: "Block",
		reportTitle: "Why are you reporting?",
		reasonSpam: "Spam or ads",
		reasonFake: "Fake profile",
		reasonHarass: "Rude behavior",
		reasonOther: "Something else",
		sendReport: "Send report",
		reported: "Report saved. The profile is hidden.",
		blockedToast: "Blocked and hidden.",
		about: "About",
		close: "Close",
		likesYou: "Liked you",
		likesYouLocked: "Premium reveals the names.",
		someone: "Someone nearby",
		noMatches: "No mutual likes yet",
		noMatchesBody: "When a like is returned, they show up here.",
		write: "Write a message",
		send: "Send",
		chatNote: "The bot would notify them. This thread stays in the preview.",
		you: "You",
		premiumLead: "More likes, see who liked you, and a boost for your profile.",
		starsNote: "In the bot, checkout uses Telegram Stars. This purchase is a demonstration — nothing is charged.",
		perksTitle: "Premium includes",
		perkLikes: "40 likes a day instead of 8",
		perkSee: "See who already liked you",
		perkBoost: "A profile boost sold separately",
		perkFilters: "Filters for age, country, and intention",
		activeUntil: "Premium until",
		freeNow: "You’re on the free plan: 8 likes a day.",
		boostActive: "Profile boosted until",
		productLikes: "10 extra likes",
		productLikesBody: "They don’t reset at midnight. Used after the daily cap.",
		productBoost: "Boost your profile",
		productBoostBody: "A short lift. In this preview it lasts 30 minutes.",
		productWeek: "Premium for 7 days",
		productWeekBody: "More likes, and likes you’ve received.",
		productMonth: "Premium for 30 days",
		productMonthBody: "The same set, for a longer stretch.",
		getFor: "Get for",
		purchased: "Done. The bot would show a Stars receipt here.",
		yourProfile: "Your profile",
		photoNote: "In the bot, a photo goes here after moderation. This preview uses a star mark.",
		boostedUntil: "Boosted until",
		notBoosted: "Your profile is in the regular feed.",
		language: "Language",
		privacy: "Privacy",
		privacyBody: "Others see your name, age, city, interests, and note. Not a birth date or a precise address.",
		safety: "Safety",
		safetyBody: "A report or block hides that person from your feed. In the service, moderation reviews it.",
		deleteAccount: "Delete this profile from the device",
		deleteBody: "Removes your name, note, likes, and chats from this preview.",
		deleteConfirm: "Delete everything",
		goalLabel: "Intention",
		lookingLabel: "Show me",
		editProfile: "Edit profile",
		botTitle: "What the bot does",
		botStart: "Sign-up and language — the /start command",
		botNotify: "Alerts for likes and matches",
		botPay: "Premium invoices via Telegram Stars",
		brandKicker: "Mini App",
		brandTitle: "Dating that starts with a star.",
		brandBody: "A profile, likes, and a mutual spark. The bot keeps the alerts — here you meet people.",
		pointSearch: "Filter by age, country, and intention",
		pointMatch: "A match only when the like is mutual",
		pointStars: "Premium and packs — via Stars",
		adultMark: "18+",
		goals: {
			serious: "Something serious",
			dates: "Dates",
			chat: "Conversation",
			friends: "Friendship"
		},
		countries: {
			ua: "Ukraine",
			pl: "Poland",
			de: "Germany",
			es: "Spain",
			fr: "France",
			it: "Italy",
			jp: "Japan",
			nl: "Netherlands",
			pt: "Portugal",
			gb: "United Kingdom",
			us: "United States"
		},
		cities: {
			kyiv: "Kyiv",
			lviv: "Lviv",
			odesa: "Odesa",
			dnipro: "Dnipro",
			warsaw: "Warsaw",
			krakow: "Kraków",
			berlin: "Berlin",
			munich: "Munich",
			barcelona: "Barcelona",
			madrid: "Madrid",
			paris: "Paris",
			lyon: "Lyon",
			milan: "Milan",
			rome: "Rome",
			tokyo: "Tokyo",
			osaka: "Osaka",
			amsterdam: "Amsterdam",
			lisbon: "Lisbon",
			london: "London",
			newyork: "New York"
		},
		interests: {
			music: "Music",
			travel: "Travel",
			coffee: "Coffee",
			sport: "Sport",
			cinema: "Cinema",
			books: "Books",
			cooking: "Cooking",
			art: "Art",
			hiking: "Walking",
			photo: "Photo",
			dance: "Dance",
			design: "Design",
			food: "Food",
			languages: "Languages"
		}
	}
};
function placeLine(t, country, city) {
	return `${cityName(t, city)}, ${countryName(t, country)}`;
}
function countryName(t, id) {
	return t.countries[id] ?? id;
}
function cityName(t, id) {
	return t.cities[id] ?? id;
}
function interestName(t, id) {
	return t.interests[id] ?? id;
}
function ageWords(age, lang) {
	if (lang === "en") return String(age);
	const n = age % 100;
	const n10 = age % 10;
	if (n > 10 && n < 20) return `${age} років`;
	if (n10 === 1) return `${age} рік`;
	if (n10 >= 2 && n10 <= 4) return `${age} роки`;
	return `${age} років`;
}
function goalText(t, goal) {
	return t.goals[goal];
}
var COUNTRY_IDS = [
	"ua",
	"pl",
	"de",
	"es",
	"fr",
	"it",
	"jp",
	"nl",
	"pt",
	"gb",
	"us"
];
var CITIES = {
	ua: [
		"kyiv",
		"lviv",
		"odesa",
		"dnipro"
	],
	pl: ["warsaw", "krakow"],
	de: ["berlin", "munich"],
	es: ["barcelona", "madrid"],
	fr: ["paris", "lyon"],
	it: ["milan", "rome"],
	jp: ["tokyo", "osaka"],
	nl: ["amsterdam"],
	pt: ["lisbon"],
	gb: ["london"],
	us: ["newyork"]
};
var INTEREST_IDS = [
	"music",
	"travel",
	"coffee",
	"sport",
	"cinema",
	"books",
	"cooking",
	"art",
	"hiking",
	"photo",
	"dance",
	"design",
	"food",
	"languages"
];
var people = [
	{
		id: "elena",
		name: "Elena",
		age: 28,
		gender: "woman",
		country: "pl",
		city: "warsaw",
		goal: "dates",
		interests: [
			"books",
			"art",
			"travel"
		],
		bio: {
			uk: "Редакторка у Варшаві. Люблю довгі книжки й короткі прогулянки після роботи.",
			en: "Editor in Warsaw. Long books, and a short walk after work."
		},
		hello: {
			uk: "Вітаю. Що ти зараз читаєш — або навмисно не читаєш?",
			en: "Hello. What are you reading — or deliberately not reading?"
		},
		reply: {
			uk: "Добре. Тоді без дрібниць: що тебе зараз справді займає?",
			en: "Good. Then skip the small talk: what actually has your attention?"
		},
		likedYou: false
	},
	{
		id: "sofia",
		name: "Sofia",
		age: 26,
		gender: "woman",
		country: "ua",
		city: "kyiv",
		goal: "serious",
		interests: [
			"design",
			"coffee",
			"cinema"
		],
		bio: {
			uk: "Дизайнерка з Києва. Шукаю спокійні вечори й людину, з якою не треба вдавати.",
			en: "Designer in Kyiv. Quiet evenings, and someone I don’t have to perform for."
		},
		hello: {
			uk: "Привіт. У твоїй анкеті немає пози. Як твій вечір?",
			en: "Hi. Your profile isn’t posing. How’s your evening?"
		},
		reply: {
			uk: "Мені близькі спокійні люди. Що в тебе цього тижня не для галочки?",
			en: "Calm people suit me. What’s on your week that isn’t for show?"
		},
		likedYou: true
	},
	{
		id: "luca",
		name: "Luca",
		age: 29,
		gender: "man",
		country: "it",
		city: "milan",
		goal: "dates",
		interests: [
			"food",
			"music",
			"travel"
		],
		bio: {
			uk: "Готую краще, ніж планую. Шукаю вечерю, яка може стати звичкою.",
			en: "I cook better than I plan. Looking for dinner that might become a habit."
		},
		hello: {
			uk: "Ciao. Ти більше про довгу вечерю чи каву навстоячки?",
			en: "Ciao. Are you a long dinner, or coffee standing up?"
		},
		reply: {
			uk: "Тоді я ставлю воду, а ти обираєш: паста чи щось простіше.",
			en: "Then I’ll boil the water. You pick: pasta, or something simpler."
		},
		likedYou: false
	},
	{
		id: "yara",
		name: "Yara",
		age: 24,
		gender: "woman",
		country: "es",
		city: "barcelona",
		goal: "chat",
		interests: [
			"dance",
			"photo",
			"music"
		],
		bio: {
			uk: "Танцюю й знімаю місто. Якщо не боїшся спонтанного квитка — напиши.",
			en: "I dance and photograph the city. If a spontaneous ticket doesn’t scare you, say hi."
		},
		hello: {
			uk: "Гей. Якщо ти в місті цього тижня, я знаю терасу з нормальним світлом.",
			en: "Hey. If you’re in town this week, I know a terrace with decent light."
		},
		reply: {
			uk: "Ловлю. Назви одне місце, куди пішов би завтра без плану.",
			en: "I’m in. Name one place you’d go tomorrow with no plan."
		},
		likedYou: true
	},
	{
		id: "noah",
		name: "Noah",
		age: 32,
		gender: "man",
		country: "de",
		city: "berlin",
		goal: "serious",
		interests: [
			"art",
			"hiking",
			"cinema"
		],
		bio: {
			uk: "Роблю виставки в Берліні. Цікаві люди зі смаком, не з ідеальною анкетою.",
			en: "I make exhibitions in Berlin. I’m interested in taste, not a perfect profile."
		},
		hello: {
			uk: "Привіт. Не обов’язково бути в Берліні — цікаво, що обираєш, коли є час.",
			en: "Hey. You don’t have to be in Berlin. I’m curious what you choose when you have time."
		},
		reply: {
			uk: "Мені цього досить, щоб продовжити. Який у тебе сьогодні темп?",
			en: "That’s enough for me to keep going. What’s your pace today?"
		},
		likedYou: true
	},
	{
		id: "camille",
		name: "Camille",
		age: 27,
		gender: "woman",
		country: "fr",
		city: "paris",
		goal: "serious",
		interests: [
			"books",
			"cooking",
			"languages"
		],
		bio: {
			uk: "Працюю з книжками в Парижі. Ціную ясний розум і людей, які відповідають.",
			en: "I work with books in Paris. Clear minds, and people who actually reply."
		},
		hello: {
			uk: "Привіт. Почни з однієї чесної речі про цей тиждень.",
			en: "Hello. Start with one honest thing about your week."
		},
		reply: {
			uk: "Чесно — вже краще за більшість чатів. Розкажи ще одну деталь.",
			en: "Honest already beats most chats. Give me one more detail."
		},
		likedYou: false
	},
	{
		id: "kenji",
		name: "Kenji",
		age: 30,
		gender: "man",
		country: "jp",
		city: "tokyo",
		goal: "chat",
		interests: [
			"photo",
			"design",
			"coffee"
		],
		bio: {
			uk: "Знімаю нічне місто й п’ю забагато кави. Хочу розмову, через яку не шкода не спати.",
			en: "I shoot the city at night and drink too much coffee. I want a talk worth losing sleep over."
		},
		hello: {
			uk: "Привіт. Ніч чи ранок — коли ти найкраще розмовляєш?",
			en: "Hi. Night or morning — when do you actually talk?"
		},
		reply: {
			uk: "Добре звучить. Я ще не сплю — де ти зараз подумки?",
			en: "That sounds right. I’m still up — where is your head right now?"
		},
		likedYou: false
	},
	{
		id: "omar",
		name: "Omar",
		age: 36,
		gender: "man",
		country: "nl",
		city: "amsterdam",
		goal: "friends",
		interests: [
			"sport",
			"cooking",
			"travel"
		],
		bio: {
			uk: "Амстердам, багато доріг і нормальна кухня. Спершу жива дружба — далі видно.",
			en: "Amsterdam, too many trains, decent cooking. Friendship first — then we’ll see."
		},
		hello: {
			uk: "Привіт. Я за прості плани: прогулянка, їжа, без анкети вголос.",
			en: "Hi. Simple plans: a walk, food, no interview voice."
		},
		reply: {
			uk: "Домовились. Без анкети: кава, вода чи вже вечеря?",
			en: "Deal. No profile talk: coffee, water, or dinner already?"
		},
		likedYou: false
	}
];
function selectPeople(s, mode) {
	return people.filter((person) => {
		if (s.blocked.includes(person.id)) return false;
		if (s.likes.includes(person.id)) return false;
		if (s.passes.includes(person.id)) return false;
		if (mode === "liked" && !person.likedYou) return false;
		if (s.profile?.looking === "women" && person.gender !== "woman") return false;
		if (s.profile?.looking === "men" && person.gender !== "man") return false;
		if (mode === "deck") {
			if (person.age < s.filters.ageMin || person.age > s.filters.ageMax) return false;
			if (s.filters.goal !== "any" && person.goal !== s.filters.goal) return false;
			if (s.filters.sameCountry && s.profile && person.country !== s.profile.country) return false;
		}
		return true;
	});
}
function findPerson(id) {
	return people.find((person) => person.id === id);
}
var fresh = () => ({
	lang: null,
	adult: false,
	profile: null,
	likes: [],
	passes: [],
	matches: [],
	blocked: [],
	reports: [],
	premiumUntil: null,
	extraLikes: 0,
	likesUsedToday: 0,
	likeDay: "",
	boostedUntil: null,
	messages: {},
	filters: {
		ageMin: 18,
		ageMax: 45,
		goal: "any",
		sameCountry: false
	},
	tab: "discover",
	seenMatchCount: 0
});
function dayKey(now = Date.now()) {
	const d = new Date(now);
	const month = `${d.getMonth() + 1}`.padStart(2, "0");
	const day = `${d.getDate()}`.padStart(2, "0");
	return `${d.getFullYear()}-${month}-${day}`;
}
function isPremium(s, now = Date.now()) {
	return s.premiumUntil != null && s.premiumUntil > now;
}
function likeBudget(s, now = Date.now()) {
	const used = s.likeDay === dayKey(now) ? s.likesUsedToday : 0;
	const cap = isPremium(s, now) ? 40 : 8;
	const dailyLeft = Math.max(0, cap - used);
	return {
		cap,
		dailyLeft,
		extra: s.extraLikes,
		total: dailyLeft + s.extraLikes
	};
}
function clampAge(n) {
	return Math.min(80, Math.max(18, n));
}
var useLoveStore = create()(persist((set, get) => ({
	...fresh(),
	setLang: (lang) => set({ lang }),
	confirmAdult: () => set({ adult: true }),
	saveProfile: (profile) => set({
		profile,
		tab: "discover"
	}),
	setFilters: (patch) => set((s) => {
		let ageMin = clampAge(patch.ageMin ?? s.filters.ageMin);
		let ageMax = clampAge(patch.ageMax ?? s.filters.ageMax);
		if (ageMin > ageMax) {
			if (patch.ageMin != null) ageMax = ageMin;
			else ageMin = ageMax;
		}
		return { filters: {
			...s.filters,
			...patch,
			ageMin,
			ageMax
		} };
	}),
	openTab: (tab) => set((s) => ({
		tab,
		seenMatchCount: tab === "matches" ? s.matches.length : s.seenMatchCount
	})),
	pass: (id) => set((s) => {
		if (s.passes.includes(id) || s.likes.includes(id) || s.blocked.includes(id)) return s;
		return { passes: [...s.passes, id] };
	}),
	like: (id) => {
		const s = get();
		if (s.likes.includes(id) || s.passes.includes(id) || s.blocked.includes(id)) return {
			ok: false,
			reason: "seen"
		};
		const now = Date.now();
		const day = dayKey(now);
		const used = s.likeDay === day ? s.likesUsedToday : 0;
		const cap = isPremium(s, now) ? 40 : 8;
		let likesUsedToday = used;
		let extraLikes = s.extraLikes;
		if (used < cap) likesUsedToday = used + 1;
		else if (extraLikes > 0) extraLikes -= 1;
		else return {
			ok: false,
			reason: "limit"
		};
		const person = findPerson(id);
		const matched = Boolean(person?.likedYou);
		const messages = { ...s.messages };
		if (matched && person) messages[id] = [{
			from: "them",
			text: person.hello[s.lang ?? "uk"],
			at: now
		}];
		set({
			likes: [...s.likes, id],
			matches: matched ? [...s.matches, id] : s.matches,
			messages,
			likesUsedToday,
			extraLikes,
			likeDay: day
		});
		return {
			ok: true,
			matched
		};
	},
	block: (id) => set((s) => ({ blocked: s.blocked.includes(id) ? s.blocked : [...s.blocked, id] })),
	report: (id, reason) => set((s) => ({
		reports: [...s.reports, {
			id,
			reason,
			at: Date.now()
		}],
		blocked: s.blocked.includes(id) ? s.blocked : [...s.blocked, id]
	})),
	resetPasses: () => set({ passes: [] }),
	buy: (id) => set((s) => {
		const now = Date.now();
		if (id === "likes10") return { extraLikes: s.extraLikes + 10 };
		if (id === "boost") return { boostedUntil: now + 18e5 };
		const days = id === "week" ? 7 : 30;
		return { premiumUntil: Math.max(now, s.premiumUntil ?? 0) + days * 24 * 60 * 60 * 1e3 };
	}),
	sendMessage: (id, text) => {
		const clean = text.trim().slice(0, 500);
		if (!clean) return;
		const s = get();
		const prev = s.messages[id] ?? [];
		const mine = prev.filter((m) => m.from === "me").length;
		set({ messages: {
			...s.messages,
			[id]: [...prev, {
				from: "me",
				text: clean,
				at: Date.now()
			}]
		} });
		if (mine > 0) return;
		const person = findPerson(id);
		if (!person) return;
		const reply = person.reply[s.lang ?? "uk"];
		window.setTimeout(() => {
			const cur = get();
			if (cur.blocked.includes(id)) return;
			if ((cur.messages[id] ?? []).some((m) => m.text === reply)) return;
			set({ messages: {
				...get().messages,
				[id]: [...get().messages[id] ?? [], {
					from: "them",
					text: reply,
					at: Date.now()
				}]
			} });
		}, 800);
	},
	deleteAccount: () => set(fresh())
}), {
	name: "lovestar-v1",
	skipHydration: true,
	partialize: (s) => ({
		lang: s.lang,
		adult: s.adult,
		profile: s.profile,
		likes: s.likes,
		passes: s.passes,
		matches: s.matches,
		blocked: s.blocked,
		reports: s.reports,
		premiumUntil: s.premiumUntil,
		extraLikes: s.extraLikes,
		likesUsedToday: s.likesUsedToday,
		likeDay: s.likeDay,
		boostedUntil: s.boostedUntil,
		messages: s.messages,
		filters: s.filters,
		tab: s.tab,
		seenMatchCount: s.seenMatchCount
	})
}));
var TOPS = [
	"top-8",
	"top-12",
	"top-16",
	"top-20"
];
function StarMark({ className }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("svg", {
		viewBox: "0 0 24 24",
		className,
		"aria-hidden": "true",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("path", {
			fill: "currentColor",
			d: "M12 2.2 14.7 8.8 21.6 9.4 16.3 14.1 17.9 21 12 17.4 6.1 21 7.7 14.1 2.4 9.4 9.3 8.8Z"
		})
	});
}
function Portrait({ name, className }) {
	const letter = name.slice(0, 1).toUpperCase();
	const top = TOPS[name.length % TOPS.length];
	const marks = name.charCodeAt(0) % 3 + 1;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "night relative overflow-hidden " + (className ?? ""),
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
				className: "initial pointer-events-none absolute -left-1 top-1",
				children: letter
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "hairline absolute inset-x-5 h-px " + top }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "absolute bottom-4 left-4 flex gap-1 text-gold",
				children: Array.from({ length: marks }, (_, i) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(StarMark, { className: "size-3" }, i))
			})
		]
	});
}
function Sheet({ open, title, closeLabel, onClose, children }) {
	(0, import_react.useEffect)(() => {
		if (!open) return;
		const onKey = (e) => {
			if (e.key === "Escape") onClose();
		};
		window.addEventListener("keydown", onKey);
		return () => window.removeEventListener("keydown", onKey);
	}, [open, onClose]);
	if (!open) return null;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "absolute inset-0 z-30 flex flex-col justify-end",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
			type: "button",
			className: "absolute inset-0 bg-bg/70",
			"aria-label": closeLabel,
			onClick: onClose
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			role: "dialog",
			"aria-modal": "true",
			"aria-label": title,
			className: "relative max-h-[86%] overflow-y-auto rounded-t-4xl border border-line bg-surface px-5 pt-4 pb-6",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mb-4 flex items-center justify-between gap-3",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
					className: "font-display text-2xl",
					children: title
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					type: "button",
					className: "grid size-11 place-items-center rounded-full border border-line text-fg",
					onClick: onClose,
					"aria-label": closeLabel,
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(X, { className: "size-5" })
				})]
			}), children]
		})]
	});
}
function Chip({ on, children, onClick }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
		type: "button",
		"aria-pressed": on,
		onClick,
		className: "min-h-11 rounded-full border px-4 text-sm " + (on ? "border-gold bg-gold text-ink" : "border-line bg-raised text-fg"),
		children
	});
}
function GoldButton({ children, onClick, type = "button" }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
		type,
		onClick,
		className: "min-h-12 w-full rounded-full bg-gold px-5 font-medium text-ink",
		children
	});
}
var REASONS = [
	"spam",
	"fake",
	"harass",
	"other"
];
function Discover({ onMatch, onNotify, onGoPremium }) {
	const lang = useLoveStore((s) => s.lang) ?? "uk";
	const t = copy[lang];
	const profile = useLoveStore((s) => s.profile);
	const filters = useLoveStore((s) => s.filters);
	const likes = useLoveStore((s) => s.likes);
	const passes = useLoveStore((s) => s.passes);
	const blocked = useLoveStore((s) => s.blocked);
	const pass = useLoveStore((s) => s.pass);
	const like = useLoveStore((s) => s.like);
	const report = useLoveStore((s) => s.report);
	const block = useLoveStore((s) => s.block);
	const resetPasses = useLoveStore((s) => s.resetPasses);
	const setFilters = useLoveStore((s) => s.setFilters);
	const budget = useLoveStore((s) => likeBudget(s));
	const openTab = useLoveStore((s) => s.openTab);
	const deck = selectPeople({
		profile,
		filters,
		likes,
		passes,
		blocked
	}, "deck");
	const top = deck[0];
	const next = deck[1];
	const [sheet, setSheet] = (0, import_react.useState)(null);
	const [reason, setReason] = (0, import_react.useState)("spam");
	const keysLocked = sheet != null;
	(0, import_react.useEffect)(() => {
		const onKey = (e) => {
			if (keysLocked) return;
			const tag = e.target?.tagName;
			if (tag === "INPUT" || tag === "TEXTAREA" || tag === "SELECT") return;
			if (e.key === "ArrowLeft" && top) commit("pass");
			if (e.key === "ArrowRight" && top) commit("like");
		};
		window.addEventListener("keydown", onKey);
		return () => window.removeEventListener("keydown", onKey);
	});
	function commit(dir) {
		if (!top) return;
		if (dir === "pass") {
			pass(top.id);
			return;
		}
		if (likeBudget(useLoveStore.getState()).total < 1) {
			setSheet("paywall");
			return;
		}
		const res = like(top.id);
		if (!res.ok && res.reason === "limit") setSheet("paywall");
		if (res.ok && res.matched) onMatch(top.id);
	}
	const reasonLabel = {
		spam: t.reasonSpam,
		fake: t.reasonFake,
		harass: t.reasonHarass,
		other: t.reasonOther
	};
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "relative flex h-full min-h-0 flex-col",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("header", {
				className: "flex items-center justify-between px-4 pt-4 pb-2",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex items-center gap-2",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(StarMark, { className: "size-5 text-gold" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "font-display text-lg",
						children: "LOVE STAR"
					})]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex items-center gap-2",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
						type: "button",
						className: "min-h-11 rounded-full border border-line px-3 text-sm tabular-nums",
						onClick: () => openTab("premium"),
						children: [
							budget.total,
							" ",
							t.today
						]
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						type: "button",
						className: "grid size-11 place-items-center rounded-full border border-line",
						"aria-label": t.filters,
						onClick: () => setSheet("filters"),
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SlidersHorizontal, { className: "size-5" })
					})]
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "px-4 pb-2 text-xs text-muted",
				children: t.demoPeople
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "relative mx-4 min-h-0 flex-1",
				children: [next ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "absolute inset-x-2 top-3 bottom-0 overflow-hidden rounded-4xl border border-line opacity-70",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Portrait, {
						name: next.name,
						className: "h-full"
					})
				}) : null, top ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SwipeCard, {
					person: top,
					goal: goalText(t, top.goal),
					place: placeLine(t, top.country, top.city),
					canLike: budget.total > 0,
					onNeedLikes: () => setSheet("paywall"),
					onDone: (dir) => {
						if (dir === "pass") pass(top.id);
						else {
							const res = like(top.id);
							if (!res.ok && res.reason === "limit") setSheet("paywall");
							if (res.ok && res.matched) onMatch(top.id);
						}
					}
				}, top.id) : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex h-full flex-col items-start justify-center rounded-4xl border border-line bg-surface px-5",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
							className: "font-display text-3xl",
							children: t.emptyTitle
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mt-2 text-muted",
							children: passes.length ? t.emptyBody : t.allHidden
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "mt-5 grid w-full gap-3",
							children: [passes.length > 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(GoldButton, {
								onClick: () => resetPasses(),
								children: t.replay
							}) : null, /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
								type: "button",
								className: "min-h-12 rounded-full border border-line",
								onClick: () => setSheet("filters"),
								children: t.filters
							})]
						})
					]
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex items-center justify-center gap-4 px-4 py-3",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						type: "button",
						className: "grid size-14 place-items-center rounded-full border border-line bg-surface",
						"aria-label": t.pass,
						disabled: !top,
						onClick: () => commit("pass"),
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(X, { className: "size-6" })
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						type: "button",
						className: "grid size-12 place-items-center rounded-full border border-line bg-surface",
						"aria-label": t.details,
						disabled: !top,
						onClick: () => setSheet("details"),
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Info, { className: "size-5" })
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						type: "button",
						className: "grid size-16 place-items-center rounded-full bg-gold text-ink disabled:opacity-40",
						"aria-label": t.like,
						disabled: !top,
						onClick: () => commit("like"),
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Heart, { className: "size-7" })
					})
				]
			}),
			likes.length === 0 && passes.length === 0 && top ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "px-6 pb-2 text-center text-xs text-muted",
				children: t.hintSwipe
			}) : null,
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Sheet, {
				open: sheet === "filters",
				title: t.filters,
				closeLabel: t.close,
				onClose: () => setSheet(null),
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "grid gap-4",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Stepper, {
							label: t.ageFrom,
							value: filters.ageMin,
							onChange: (ageMin) => setFilters({ ageMin })
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Stepper, {
							label: t.ageTo,
							value: filters.ageMax,
							onChange: (ageMax) => setFilters({ ageMax })
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "flex flex-wrap gap-2",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(FilterChip, {
								on: filters.goal === "any",
								label: t.anyGoal,
								onClick: () => setFilters({ goal: "any" })
							}), Object.keys(t.goals).map((id) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(FilterChip, {
								on: filters.goal === id,
								label: t.goals[id],
								onClick: () => setFilters({ goal: id })
							}, id))]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
							type: "button",
							"aria-pressed": filters.sameCountry,
							className: "min-h-11 rounded-full border px-4 text-sm " + (filters.sameCountry ? "border-gold bg-gold text-ink" : "border-line"),
							onClick: () => setFilters({ sameCountry: !filters.sameCountry }),
							children: t.sameCountry
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(GoldButton, {
							onClick: () => setSheet(null),
							children: t.done
						})
					]
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Sheet, {
				open: sheet === "details" && Boolean(top),
				title: t.about,
				closeLabel: t.close,
				onClose: () => setSheet(null),
				children: top ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "grid gap-3",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
							className: "font-display text-3xl",
							children: [
								top.name,
								" ",
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "text-muted tabular-nums",
									children: top.age
								})
							]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "text-sm text-muted",
							children: placeLine(t, top.country, top.city)
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", { children: goalText(t, top.goal) }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", { children: top.bio[lang] }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "flex flex-wrap gap-2",
							children: top.interests.map((id) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "rounded-full border border-line px-3 py-1 text-sm",
								children: interestName(t, id)
							}, id))
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
							type: "button",
							className: "flex min-h-12 items-center gap-2 rounded-2xl border border-line px-4",
							onClick: () => setSheet("report"),
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Flag, { className: "size-4" }),
								" ",
								t.report
							]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
							type: "button",
							className: "flex min-h-12 items-center gap-2 rounded-2xl border border-line px-4",
							onClick: () => {
								block(top.id);
								setSheet(null);
								onNotify(t.blockedToast);
							},
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(X, { className: "size-4" }),
								" ",
								t.block
							]
						})
					]
				}) : null
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Sheet, {
				open: sheet === "report",
				title: t.reportTitle,
				closeLabel: t.close,
				onClose: () => setSheet(null),
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "grid gap-2",
					children: [REASONS.map((id) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						type: "button",
						"aria-pressed": reason === id,
						className: "min-h-12 rounded-2xl border px-4 text-left " + (reason === id ? "border-gold bg-gold text-ink" : "border-line"),
						onClick: () => setReason(id),
						children: reasonLabel[id]
					}, id)), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(GoldButton, {
						onClick: () => {
							if (!top) return;
							report(top.id, reason);
							setSheet(null);
							onNotify(t.reported);
						},
						children: t.sendReport
					})]
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Sheet, {
				open: sheet === "paywall",
				title: t.limitTitle,
				closeLabel: t.close,
				onClose: () => setSheet(null),
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-muted",
					children: t.limitBody
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "mt-4 grid gap-3",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(GoldButton, {
						onClick: () => {
							setSheet(null);
							onGoPremium();
						},
						children: t.seePremium
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						type: "button",
						className: "min-h-12 rounded-full border border-line",
						onClick: () => setSheet(null),
						children: t.later
					})]
				})]
			})
		]
	});
}
function FilterChip({ on, label, onClick }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
		type: "button",
		"aria-pressed": on,
		onClick,
		className: "min-h-11 rounded-full border px-4 text-sm " + (on ? "border-gold bg-gold text-ink" : "border-line"),
		children: label
	});
}
function Stepper({ label, value, onChange }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "flex items-center justify-between gap-3",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: label }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "flex items-center gap-2",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					type: "button",
					className: "grid size-11 place-items-center rounded-full border border-line",
					"aria-label": label,
					onClick: () => onChange(value - 1),
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Minus, { className: "size-4" })
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
					className: "w-8 text-center tabular-nums",
					children: value
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					type: "button",
					className: "grid size-11 place-items-center rounded-full border border-line",
					"aria-label": label,
					onClick: () => onChange(value + 1),
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Plus, { className: "size-4" })
				})
			]
		})]
	});
}
function SwipeCard({ person, place, goal, canLike, onNeedLikes, onDone }) {
	const origin = (0, import_react.useRef)({
		x: 0,
		y: 0
	});
	const pointRef = (0, import_react.useRef)({
		x: 0,
		y: 0,
		dragging: false
	});
	const [point, setPoint] = (0, import_react.useState)({
		x: 0,
		y: 0,
		dragging: false
	});
	const gone = (0, import_react.useRef)(false);
	function move(next) {
		pointRef.current = next;
		setPoint(next);
	}
	function finish(dir) {
		if (gone.current) return;
		if (dir === "like" && !canLike) {
			onNeedLikes();
			move({
				x: 0,
				y: 0,
				dragging: false
			});
			return;
		}
		gone.current = true;
		const reduced = window.matchMedia("(prefers-reduced-motion: reduce)").matches;
		move({
			x: dir === "like" ? 520 : -520,
			y: 24,
			dragging: false
		});
		window.setTimeout(() => onDone(dir), reduced ? 0 : 200);
	}
	const likeStamp = Math.min(1, Math.max(0, point.x / 120));
	const passStamp = Math.min(1, Math.max(0, -point.x / 120));
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("article", {
		className: "motion absolute inset-0 touch-none overflow-hidden rounded-4xl border border-line select-none",
		style: {
			transform: `translate3d(${point.x}px, ${point.y}px, 0) rotate(${point.x / 18}deg)`,
			transition: point.dragging ? "none" : "transform 200ms ease"
		},
		onPointerDown: (e) => {
			if (gone.current) return;
			origin.current = {
				x: e.clientX,
				y: e.clientY
			};
			e.currentTarget.setPointerCapture(e.pointerId);
			move({
				x: 0,
				y: 0,
				dragging: true
			});
		},
		onPointerMove: (e) => {
			if (!pointRef.current.dragging || gone.current) return;
			move({
				x: e.clientX - origin.current.x,
				y: (e.clientY - origin.current.y) * .25,
				dragging: true
			});
		},
		onPointerUp: () => {
			const current = pointRef.current;
			if (!current.dragging || gone.current) return;
			if (current.x > 96) finish("like");
			else if (current.x < -96) finish("pass");
			else move({
				x: 0,
				y: 0,
				dragging: false
			});
		},
		onPointerCancel: () => move({
			x: 0,
			y: 0,
			dragging: false
		}),
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Portrait, {
				name: person.name,
				className: "absolute inset-0"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "card-shade absolute inset-0" }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "absolute top-8 left-5 rounded-2xl border border-gold px-3 py-1 font-display text-2xl text-gold",
				style: { opacity: likeStamp },
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Heart, { className: "size-6" })
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "absolute top-8 right-5 rounded-2xl border border-line px-3 py-1 text-fg",
				style: { opacity: passStamp },
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(X, { className: "size-6" })
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "absolute inset-x-0 bottom-0 p-4",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex items-end gap-2",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
							className: "font-display text-4xl",
							children: person.name
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "mb-1 text-xl text-muted tabular-nums",
							children: person.age
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-1 text-sm text-muted",
						children: place
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-2 text-sm",
						children: goal
					})
				]
			})
		]
	});
}
var NAME = /^[\p{L}][\p{L}\s'’.-]{1,23}$/u;
var LINK = /https?:\/\/|www\.|t\.me\/|@\w/i;
var field = "h-12 w-full rounded-2xl border border-line bg-raised px-4 text-fg outline-none";
function Language() {
	const setLang = useLoveStore((s) => s.setLang);
	const t = copy.uk;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "flex h-full flex-col justify-between px-6 py-8",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(StarMark, { className: "size-8 text-gold" }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-6 text-sm tracking-wide text-gold",
				children: t.adultMark
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
				className: "mt-3 font-display text-4xl",
				children: "LOVE STAR"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-3 text-muted",
				children: t.langLead
			})
		] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "mb-3 text-sm text-muted",
			children: t.chooseLang
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "grid gap-3",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(GoldButton, {
				onClick: () => setLang("uk"),
				children: "Українська"
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
				type: "button",
				className: "min-h-12 w-full rounded-full border border-line text-fg",
				onClick: () => setLang("en"),
				children: "English"
			})]
		})] })]
	});
}
function Age() {
	const lang = useLoveStore((s) => s.lang) ?? "uk";
	const confirmAdult = useLoveStore((s) => s.confirmAdult);
	const t = copy[lang];
	const [blocked, setBlocked] = (0, import_react.useState)(false);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "flex h-full flex-col px-6 py-8",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Shield, { className: "size-8 text-gold" }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
				className: "mt-6 font-display text-4xl",
				children: t.ageTitle
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-3 text-muted",
				children: blocked ? t.ageBlocked : t.ageBody
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "mt-auto grid gap-3",
				children: blocked ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					type: "button",
					className: "min-h-12 rounded-full border border-line",
					onClick: () => setBlocked(false),
					children: t.back
				}) : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(GoldButton, {
					onClick: () => confirmAdult(),
					children: t.ageYes
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					type: "button",
					className: "min-h-12 rounded-full border border-line",
					onClick: () => setBlocked(true),
					children: t.ageNo
				})] })
			})
		]
	});
}
function Wizard({ editing, onCancel }) {
	const lang = useLoveStore((s) => s.lang) ?? "uk";
	const profile = useLoveStore((s) => s.profile);
	const saveProfile = useLoveStore((s) => s.saveProfile);
	const t = copy[lang];
	const [step, setStep] = (0, import_react.useState)(0);
	const [error, setError] = (0, import_react.useState)(null);
	const [draft, setDraft] = (0, import_react.useState)(() => ({
		name: profile?.name ?? "",
		age: profile ? String(profile.age) : "",
		country: profile?.country ?? "ua",
		city: profile?.city ?? "kyiv",
		looking: profile?.looking ?? "everyone",
		goal: profile?.goal ?? null,
		interests: profile?.interests ?? [],
		bio: profile?.bio ?? ""
	}));
	function citiesFor(country) {
		return CITIES[country] ?? [];
	}
	function problem(at) {
		if (at === 0 && !NAME.test(draft.name.trim())) return t.errName;
		if (at === 1) {
			const n = Number(draft.age);
			if (!Number.isInteger(n) || n < 18 || n > 80) return t.errAge;
		}
		if (at === 4 && !draft.goal) return t.errGoal;
		if (at === 5 && (draft.interests.length < 2 || draft.interests.length > 5)) return t.errInterests;
		if (at === 6) {
			const bio = draft.bio.trim();
			if (LINK.test(bio)) return t.errLinks;
			if (bio.length < 20 || bio.length > 280) return t.errBio;
		}
		return null;
	}
	function publish() {
		for (const at of [
			0,
			1,
			4,
			5,
			6
		]) {
			const message = problem(at);
			if (message) {
				setStep(at);
				setError(message);
				return;
			}
		}
		if (!draft.goal) return;
		const next = {
			name: draft.name.trim(),
			age: Number(draft.age),
			country: draft.country,
			city: draft.city,
			looking: draft.looking,
			goal: draft.goal,
			interests: draft.interests,
			bio: draft.bio.trim()
		};
		saveProfile(next);
		onCancel();
	}
	function forward() {
		const message = problem(step);
		if (message) {
			setError(message);
			return;
		}
		setError(null);
		if (step === 7) publish();
		else setStep((n) => n + 1);
	}
	function toggleInterest(id) {
		setDraft((d) => {
			if (d.interests.includes(id)) return {
				...d,
				interests: d.interests.filter((item) => item !== id)
			};
			if (d.interests.length >= 5) return d;
			return {
				...d,
				interests: [...d.interests, id]
			};
		});
		setError(null);
	}
	const titles = [
		t.stepName,
		t.stepAge,
		t.stepPlace,
		t.stepLook,
		t.stepGoal,
		t.stepInterests,
		t.stepBio,
		t.stepReview
	];
	const hints = [
		t.stepNameHint,
		t.stepAgeHint,
		t.stepPlaceHint,
		"",
		"",
		t.stepInterestsHint,
		t.stepBioHint,
		""
	];
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "flex h-full flex-col",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "px-5 pt-5",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-sm text-gold",
						children: editing ? t.editTitle : `${t.step} ${step + 1} / 8`
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "mt-3 flex gap-1",
						children: titles.map((_, i) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { className: "h-1 flex-1 rounded-full " + (i <= step ? "bg-gold" : "bg-line") }, i))
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
						className: "mt-4 font-display text-3xl",
						children: titles[step]
					}),
					hints[step] ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-2 text-sm text-muted",
						children: hints[step]
					}) : null
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "min-h-0 flex-1 overflow-y-auto px-5 py-4",
				children: [
					step === 0 && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
						className: field,
						value: draft.name,
						autoComplete: "off",
						placeholder: t.namePh,
						onChange: (e) => {
							setDraft({
								...draft,
								name: e.target.value
							});
							setError(null);
						}
					}),
					step === 1 && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
						className: field + " text-center font-display text-4xl",
						inputMode: "numeric",
						value: draft.age,
						placeholder: "18",
						onChange: (e) => {
							setDraft({
								...draft,
								age: e.target.value.replace(/\D/g, "").slice(0, 2)
							});
							setError(null);
						}
					}),
					step === 2 && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "grid gap-3",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
							className: "grid gap-1 text-sm text-muted",
							children: [t.country, /* @__PURE__ */ (0, import_jsx_runtime.jsx)("select", {
								className: field,
								value: draft.country,
								onChange: (e) => {
									const country = e.target.value;
									const city = citiesFor(country)[0] ?? "";
									setDraft({
										...draft,
										country,
										city
									});
								},
								children: COUNTRY_IDS.map((id) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
									value: id,
									children: t.countries[id]
								}, id))
							})]
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
							className: "grid gap-1 text-sm text-muted",
							children: [t.city, /* @__PURE__ */ (0, import_jsx_runtime.jsx)("select", {
								className: field,
								value: draft.city,
								onChange: (e) => setDraft({
									...draft,
									city: e.target.value
								}),
								children: citiesFor(draft.country).map((id) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
									value: id,
									children: cityName(t, id)
								}, id))
							})]
						})]
					}),
					step === 3 && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "flex flex-wrap gap-2",
						children: [
							["women", t.lookingWomen],
							["men", t.lookingMen],
							["everyone", t.lookingAll]
						].map(([id, label]) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Chip, {
							on: draft.looking === id,
							onClick: () => setDraft({
								...draft,
								looking: id
							}),
							children: label
						}, id))
					}),
					step === 4 && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "flex flex-wrap gap-2",
						children: Object.keys(t.goals).map((id) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Chip, {
							on: draft.goal === id,
							onClick: () => {
								setDraft({
									...draft,
									goal: id
								});
								setError(null);
							},
							children: t.goals[id]
						}, id))
					}),
					step === 5 && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "flex flex-wrap gap-2",
						children: INTEREST_IDS.map((id) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Chip, {
							on: draft.interests.includes(id),
							onClick: () => toggleInterest(id),
							children: interestName(t, id)
						}, id))
					}),
					step === 6 && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("textarea", {
						className: "min-h-36 w-full rounded-2xl border border-line bg-raised px-4 py-3 outline-none",
						value: draft.bio,
						maxLength: 280,
						placeholder: t.bioPh,
						onChange: (e) => {
							setDraft({
								...draft,
								bio: e.target.value
							});
							setError(null);
						}
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
						className: "mt-2 text-right text-sm text-muted tabular-nums",
						children: [draft.bio.trim().length, "/280"]
					})] }),
					step === 7 && draft.goal && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "grid gap-4",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Portrait, {
								name: draft.name || "L",
								className: "h-36 rounded-3xl"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "font-display text-3xl",
									children: draft.name
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "text-muted",
									children: ageWords(Number(draft.age) || 0, lang)
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "mt-1 text-sm",
									children: placeLine(t, draft.country, draft.city)
								})
							] }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
								className: "text-sm text-muted",
								children: [
									t.lookingLabel,
									": ",
									draft.looking === "women" ? t.lookingWomen : draft.looking === "men" ? t.lookingMen : t.lookingAll
								]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "text-sm",
								children: t.goals[draft.goal]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "flex flex-wrap gap-2",
								children: draft.interests.map((id) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "rounded-full border border-line px-3 py-1 text-sm",
									children: interestName(t, id)
								}, id))
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", { children: draft.bio }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "text-sm text-muted",
								children: t.photoNote
							})
						]
					}),
					error ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-3 text-sm text-fg",
						children: error
					}) : null
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "grid grid-cols-2 gap-3 px-5 pb-5",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					type: "button",
					className: "min-h-12 rounded-full border border-line disabled:opacity-40",
					disabled: !editing && step === 0,
					onClick: () => {
						setError(null);
						if (step === 0) onCancel();
						else setStep((n) => n - 1);
					},
					children: step === 0 ? t.cancel : t.back
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(GoldButton, {
					onClick: forward,
					children: step === 7 ? editing ? t.save : t.publish : t.next
				})]
			})
		]
	});
}
function Me({ onEdit }) {
	const lang = useLoveStore((s) => s.lang) ?? "uk";
	const t = copy[lang];
	const profile = useLoveStore((s) => s.profile);
	const setLang = useLoveStore((s) => s.setLang);
	const boostedUntil = useLoveStore((s) => s.boostedUntil);
	const resetPasses = useLoveStore((s) => s.resetPasses);
	const deleteAccount = useLoveStore((s) => s.deleteAccount);
	const budget = useLoveStore((s) => likeBudget(s));
	const passes = useLoveStore((s) => s.passes);
	const [confirm, setConfirm] = (0, import_react.useState)(false);
	if (!profile) return null;
	const boosted = boostedUntil != null && boostedUntil > Date.now();
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "h-full overflow-y-auto px-5 pt-5 pb-6",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
				className: "font-display text-3xl",
				children: t.yourProfile
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Portrait, {
				name: profile.name,
				className: "mt-4 h-40 rounded-3xl"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-4 font-display text-3xl",
				children: profile.name
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "text-muted",
				children: ageWords(profile.age, lang)
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-1 text-sm",
				children: placeLine(t, profile.country, profile.city)
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
				className: "mt-3 text-sm text-muted",
				children: [
					t.lookingLabel,
					": ",
					profile.looking === "women" ? t.lookingWomen : profile.looking === "men" ? t.lookingMen : t.lookingAll
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-1 text-sm",
				children: t.goals[profile.goal]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "mt-3 flex flex-wrap gap-2",
				children: profile.interests.map((id) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
					className: "rounded-full border border-line px-3 py-1 text-sm",
					children: interestName(t, id)
				}, id))
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-3",
				children: profile.bio
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-3 text-sm text-muted",
				children: t.photoNote
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
				className: "mt-3 text-sm tabular-nums",
				children: [
					budget.total,
					" ",
					t.likesToday.toLowerCase(),
					boosted && boostedUntil ? ` · ${t.boostedUntil} ${new Date(boostedUntil).toLocaleTimeString(lang === "uk" ? "uk-UA" : "en-GB", {
						hour: "2-digit",
						minute: "2-digit"
					})}` : ` · ${t.notBoosted}`
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "mt-4",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(GoldButton, {
					onClick: onEdit,
					children: t.editProfile
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
				className: "mt-6",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
					className: "text-sm text-muted",
					children: t.language
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "mt-2 flex gap-2",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						type: "button",
						"aria-pressed": lang === "uk",
						className: "min-h-11 rounded-full border px-4 " + (lang === "uk" ? "border-gold bg-gold text-ink" : "border-line"),
						onClick: () => setLang("uk"),
						children: "Українська"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						type: "button",
						"aria-pressed": lang === "en",
						className: "min-h-11 rounded-full border px-4 " + (lang === "en" ? "border-gold bg-gold text-ink" : "border-line"),
						onClick: () => setLang("en"),
						children: "English"
					})]
				})]
			}),
			passes.length > 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
				type: "button",
				className: "mt-4 min-h-11 text-sm text-gold",
				onClick: () => resetPasses(),
				children: t.replay
			}) : null,
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
				className: "mt-6 rounded-3xl border border-line bg-surface px-4 py-4",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
					className: "font-display text-xl",
					children: t.botTitle
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("ul", {
					className: "mt-2 grid gap-1 text-sm text-muted",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: t.botStart }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: t.botNotify }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: t.botPay })
					]
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
				className: "mt-3 rounded-3xl border border-line px-4 py-4",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
						className: "font-display text-xl",
						children: t.privacy
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-2 text-sm text-muted",
						children: t.privacyBody
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
						className: "mt-4 font-display text-xl",
						children: t.safety
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-2 text-sm text-muted",
						children: t.safetyBody
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
				type: "button",
				className: "mt-6 min-h-11 text-sm text-muted",
				onClick: () => setConfirm(true),
				children: t.deleteAccount
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Sheet, {
				open: confirm,
				title: t.deleteAccount,
				closeLabel: t.close,
				onClose: () => setConfirm(false),
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-muted",
					children: t.deleteBody
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "mt-4 grid gap-3",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						type: "button",
						className: "min-h-12 rounded-full bg-gold text-ink",
						onClick: () => {
							setConfirm(false);
							deleteAccount();
						},
						children: t.deleteConfirm
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						type: "button",
						className: "min-h-12 rounded-full border border-line",
						onClick: () => setConfirm(false),
						children: t.cancel
					})]
				})]
			})
		]
	});
}
function Matches({ onOpen, onMatch, onGoPremium }) {
	const t = copy[useLoveStore((s) => s.lang) ?? "uk"];
	const profile = useLoveStore((s) => s.profile);
	const filters = useLoveStore((s) => s.filters);
	const likes = useLoveStore((s) => s.likes);
	const passes = useLoveStore((s) => s.passes);
	const blocked = useLoveStore((s) => s.blocked);
	const matches = useLoveStore((s) => s.matches);
	const like = useLoveStore((s) => s.like);
	const premium = useLoveStore((s) => isPremium(s));
	const liked = selectPeople({
		profile,
		filters,
		likes,
		passes,
		blocked
	}, "liked");
	const rows = matches.map((id) => findPerson(id)).filter((person) => person && !blocked.includes(person.id));
	function take(id) {
		if (likeBudget(useLoveStore.getState()).total < 1) {
			onGoPremium();
			return;
		}
		const res = like(id);
		if (!res.ok) {
			onGoPremium();
			return;
		}
		if (res.matched) onMatch(id);
	}
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "flex h-full min-h-0 flex-col",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("header", {
			className: "px-5 pt-5 pb-3",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
				className: "font-display text-3xl",
				children: t.matchesTab
			})
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "min-h-0 flex-1 overflow-y-auto px-5 pb-4",
			children: [liked.length > 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", { children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "mb-2 flex items-center justify-between gap-2",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
						className: "text-sm text-muted",
						children: t.likesYou
					}), !premium ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Lock, { className: "size-4 text-gold" }) : null]
				}),
				!premium ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mb-3 text-sm text-muted",
					children: t.likesYouLocked
				}) : null,
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "flex gap-3 overflow-x-auto pb-2",
					children: liked.map((person) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
						type: "button",
						className: "w-28 shrink-0 text-left",
						"aria-label": premium ? `${person.name}, ${person.age}` : t.someone,
						onClick: () => premium ? take(person.id) : onGoPremium(),
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "relative h-36 overflow-hidden rounded-2xl",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Portrait, {
								name: person.name,
								className: "h-full " + (premium ? "" : "blur-md")
							}), !premium ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "absolute inset-0 grid place-items-center text-gold",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Lock, { className: "size-5" })
							}) : null]
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mt-2 truncate text-sm",
							children: premium ? `${person.name}, ${person.age}` : t.someone
						})]
					}, person.id))
				})
			] }) : null, /* @__PURE__ */ (0, import_jsx_runtime.jsx)("section", {
				className: "mt-4 grid gap-2",
				children: rows.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "rounded-3xl border border-line bg-surface px-4 py-6",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
						className: "font-display text-2xl",
						children: t.noMatches
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-2 text-sm text-muted",
						children: t.noMatchesBody
					})]
				}) : rows.map((person) => person ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
					type: "button",
					className: "flex min-h-16 items-center gap-3 rounded-2xl border border-line bg-surface px-3 text-left",
					onClick: () => onOpen(person.id),
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Portrait, {
						name: person.name,
						className: "size-12 shrink-0 rounded-full"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "block font-medium",
						children: person.name
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "block text-sm text-muted",
						children: placeLine(t, person.country, person.city)
					})] })]
				}, person.id) : null)
			})]
		})]
	});
}
function Chat({ id, onBack }) {
	const t = copy[useLoveStore((s) => s.lang) ?? "uk"];
	const person = findPerson(id);
	const messages = useLoveStore((s) => s.messages[id] ?? []);
	const sendMessage = useLoveStore((s) => s.sendMessage);
	const [text, setText] = (0, import_react.useState)("");
	const endRef = (0, import_react.useRef)(null);
	(0, import_react.useEffect)(() => {
		endRef.current?.scrollIntoView({ block: "end" });
	}, [messages.length]);
	if (!person) return null;
	function send() {
		sendMessage(id, text);
		setText("");
	}
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "flex h-full min-h-0 flex-col",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("header", {
				className: "flex items-center gap-2 border-b border-line px-3 py-3",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						type: "button",
						className: "grid size-11 place-items-center",
						"aria-label": t.back,
						onClick: onBack,
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ChevronLeft, { className: "size-6" })
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Portrait, {
						name: person.name,
						className: "size-11 rounded-full"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "font-medium",
						children: person.name
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-xs text-muted",
						children: placeLine(t, person.country, person.city)
					})] })
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "min-h-0 flex-1 space-y-2 overflow-y-auto px-4 py-4",
				children: [messages.map((msg, i) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "bubble rounded-3xl px-4 py-2 text-sm " + (msg.from === "me" ? "ml-auto bg-gold text-ink" : "bg-raised text-fg"),
					children: msg.text
				}, msg.at + "-" + i)), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { ref: endRef })]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "px-4 text-xs text-muted",
				children: t.chatNote
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("form", {
				className: "flex items-center gap-2 px-3 py-3",
				onSubmit: (e) => {
					e.preventDefault();
					send();
				},
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
					className: "h-12 min-w-0 flex-1 rounded-full border border-line bg-raised px-4 outline-none",
					value: text,
					placeholder: t.write,
					maxLength: 500,
					onChange: (e) => setText(e.target.value)
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					type: "submit",
					className: "grid size-12 place-items-center rounded-full bg-gold text-ink",
					"aria-label": t.send,
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Send, { className: "size-5" })
				})]
			})
		]
	});
}
var PRODUCTS = [
	{
		id: "likes10",
		stars: 29,
		title: "productLikes",
		body: "productLikesBody"
	},
	{
		id: "boost",
		stars: 25,
		title: "productBoost",
		body: "productBoostBody"
	},
	{
		id: "week",
		stars: 99,
		title: "productWeek",
		body: "productWeekBody"
	},
	{
		id: "month",
		stars: 249,
		title: "productMonth",
		body: "productMonthBody"
	}
];
function when(ts, lang, withTime = false) {
	return new Date(ts).toLocaleString(lang === "uk" ? "uk-UA" : "en-GB", {
		day: "numeric",
		month: "short",
		hour: withTime ? "2-digit" : void 0,
		minute: withTime ? "2-digit" : void 0
	});
}
function Premium({ onNotify }) {
	const lang = useLoveStore((s) => s.lang) ?? "uk";
	const t = copy[lang];
	const premiumUntil = useLoveStore((s) => s.premiumUntil);
	const boostedUntil = useLoveStore((s) => s.boostedUntil);
	const buy = useLoveStore((s) => s.buy);
	const premium = isPremium({ premiumUntil });
	const [pick, setPick] = (0, import_react.useState)(null);
	const perks = [
		t.perkLikes,
		t.perkSee,
		t.perkBoost,
		t.perkFilters
	];
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "flex h-full min-h-0 flex-col",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "min-h-0 flex-1 overflow-y-auto px-5 pt-5 pb-4",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex items-center gap-2 text-gold",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(StarMark, { className: "size-5" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-sm",
						children: t.premium
					})]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
					className: "mt-2 font-display text-4xl",
					children: "LOVE STAR"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-2 text-muted",
					children: t.premiumLead
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
					className: "mt-4 rounded-2xl border border-line bg-surface px-4 py-3 text-sm",
					children: [premium && premiumUntil ? `${t.activeUntil} ${when(premiumUntil, lang)}` : t.freeNow, boostedUntil && boostedUntil > Date.now() ? ` ${t.boostActive} ${when(boostedUntil, lang, true)}.` : ""]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
					className: "mt-6 font-display text-2xl",
					children: t.perksTitle
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
					className: "mt-3 grid gap-2",
					children: perks.map((perk) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
						className: "flex items-start gap-2 text-sm",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Star, { className: "mt-0.5 size-4 shrink-0 text-gold" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: perk })]
					}, perk))
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "mt-6 grid gap-3",
					children: PRODUCTS.map((product) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
						type: "button",
						className: "rounded-3xl border border-line bg-raised px-4 py-4 text-left",
						onClick: () => setPick(product),
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
							className: "flex items-center justify-between gap-3",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "font-medium",
								children: t[product.title]
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
								className: "flex items-center gap-1 text-gold tabular-nums",
								children: [product.stars, /* @__PURE__ */ (0, import_jsx_runtime.jsx)(StarMark, { className: "size-3.5" })]
							})]
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "mt-1 block text-sm text-muted",
							children: t[product.body]
						})]
					}, product.id))
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-4 text-xs text-muted",
					children: t.starsNote
				})
			]
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Sheet, {
			open: pick != null,
			title: pick ? t[pick.title] : t.premium,
			closeLabel: t.close,
			onClose: () => setPick(null),
			children: pick ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "grid gap-4",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-muted",
						children: t[pick.body]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
						className: "flex items-center gap-2 font-display text-4xl text-gold tabular-nums",
						children: [pick.stars, /* @__PURE__ */ (0, import_jsx_runtime.jsx)(StarMark, { className: "size-7" })]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(GoldButton, {
						onClick: () => {
							buy(pick.id);
							setPick(null);
							onNotify(t.purchased);
						},
						children: [
							t.getFor,
							" ",
							pick.stars
						]
					})
				]
			}) : null
		})]
	});
}
function LoveStar() {
	const [ready, setReady] = (0, import_react.useState)(false);
	(0, import_react.useEffect)(() => {
		const persisted = useLoveStore.persist;
		const unsub = persisted.onFinishHydration(() => setReady(true));
		if (persisted.hasHydrated()) setReady(true);
		else persisted.rehydrate();
		return unsub;
	}, []);
	if (!ready) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("main", {
		className: "grid h-dvh place-items-center bg-bg text-fg",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "text-center",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(StarMark, { className: "mx-auto size-8 text-gold" }),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-3 font-display text-3xl",
					children: "LOVE STAR"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-1 text-sm text-gold",
					children: "18+"
				})
			]
		})
	});
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Frame, {});
}
function Frame() {
	const lang = useLoveStore((s) => s.lang);
	const adult = useLoveStore((s) => s.adult);
	const profile = useLoveStore((s) => s.profile);
	const [editing, setEditing] = (0, import_react.useState)(false);
	const t = copy[lang ?? "uk"];
	(0, import_react.useEffect)(() => {
		if (!profile) setEditing(false);
	}, [profile]);
	let screen;
	if (!lang) screen = /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Language, {});
	else if (!adult) screen = /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Age, {});
	else if (!profile || editing) screen = /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Wizard, {
		editing: Boolean(profile) && editing,
		onCancel: () => setEditing(false)
	});
	else screen = /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Main, { onEdit: () => setEditing(true) });
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("main", {
		className: "h-dvh overflow-hidden bg-bg text-fg lg:grid lg:grid-cols-[minmax(0,1fr)_minmax(22rem,28rem)]",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("aside", {
			className: "hidden h-dvh flex-col justify-center px-10 lg:flex",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "ml-auto w-full max-w-md",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
						className: "text-sm tracking-wide text-gold",
						children: [
							t.brandKicker,
							" · ",
							t.adultMark
						]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "mt-4 flex items-center gap-3",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(StarMark, { className: "size-8 text-gold" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "font-display text-3xl",
							children: "LOVE STAR"
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
						className: "mt-6 font-display text-5xl",
						children: t.brandTitle
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-4 text-muted",
						children: t.brandBody
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
						className: "mt-8 grid gap-3 text-sm",
						children: [
							t.pointSearch,
							t.pointMatch,
							t.pointStars
						].map((point) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
							className: "flex items-center gap-3",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(StarMark, { className: "size-4 shrink-0 text-gold" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: point })]
						}, point))
					})
				]
			})
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "h-dvh lg:p-3",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "device relative mx-auto flex h-full w-full max-w-lg flex-col overflow-hidden bg-bg lg:rounded-4xl lg:border lg:border-line",
				children: screen
			})
		})]
	});
}
function Main({ onEdit }) {
	const t = copy[useLoveStore((s) => s.lang) ?? "uk"];
	const tab = useLoveStore((s) => s.tab);
	const openTab = useLoveStore((s) => s.openTab);
	const matches = useLoveStore((s) => s.matches);
	const seen = useLoveStore((s) => s.seenMatchCount);
	const [chatId, setChatId] = (0, import_react.useState)(null);
	const [matchId, setMatchId] = (0, import_react.useState)(null);
	const [toast, setToast] = (0, import_react.useState)(null);
	const badge = Math.max(0, matches.length - seen);
	const matched = matchId ? findPerson(matchId) : void 0;
	function notify(message) {
		setToast(message);
		window.setTimeout(() => setToast(null), 2400);
	}
	const tabs = [
		{
			id: "discover",
			label: t.discover,
			icon: Compass
		},
		{
			id: "matches",
			label: t.matchesTab,
			icon: Heart
		},
		{
			id: "premium",
			label: t.premium,
			icon: Star
		},
		{
			id: "me",
			label: t.me,
			icon: UserRound
		}
	];
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "relative flex h-full min-h-0 flex-col",
		children: [
			chatId ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Chat, {
				id: chatId,
				onBack: () => setChatId(null)
			}) : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "relative min-h-0 flex-1",
				children: [
					tab === "discover" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Discover, {
						onMatch: setMatchId,
						onNotify: notify,
						onGoPremium: () => openTab("premium")
					}) : null,
					tab === "matches" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Matches, {
						onOpen: setChatId,
						onMatch: (id) => {
							setMatchId(id);
						},
						onGoPremium: () => openTab("premium")
					}) : null,
					tab === "premium" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Premium, { onNotify: notify }) : null,
					tab === "me" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Me, { onEdit }) : null
				]
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("nav", {
				className: "safe-b grid grid-cols-4 border-t border-line bg-surface",
				children: tabs.map((item) => {
					const Icon = item.icon;
					const active = tab === item.id;
					return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
						type: "button",
						"aria-current": active ? "page" : void 0,
						className: "flex min-h-16 flex-col items-center justify-center gap-1 text-xs " + (active ? "text-gold" : "text-muted"),
						onClick: () => openTab(item.id),
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
							className: "relative",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Icon, { className: "size-5" }), item.id === "matches" && badge > 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "absolute -top-2 -right-3 grid min-h-5 min-w-5 place-items-center rounded-full bg-gold px-1 text-ink tabular-nums",
								children: badge
							}) : null]
						}), item.label]
					}, item.id);
				})
			})] }),
			matched ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "absolute inset-0 z-40 flex flex-col justify-end bg-bg/80 p-5",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "rounded-4xl border border-line bg-surface px-5 py-6",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Portrait, {
							name: matched.name,
							className: "mx-auto h-36 w-full rounded-3xl"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
							className: "mt-4 text-center font-display text-4xl",
							children: t.matchTitle
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
							className: "mt-2 text-center text-muted",
							children: [
								matched.name,
								". ",
								t.matchBody
							]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "mt-5 grid gap-3",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(GoldButton, {
								onClick: () => {
									openTab("matches");
									setChatId(matched.id);
									setMatchId(null);
								},
								children: t.sayHi
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
								type: "button",
								className: "min-h-12 rounded-full border border-line",
								onClick: () => setMatchId(null),
								children: t.keepLooking
							})]
						})
					]
				})
			}) : null,
			toast ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "pointer-events-none absolute inset-x-4 top-4 z-50 rounded-full border border-line bg-raised px-4 py-3 text-center text-sm",
				children: toast
			}) : null
		]
	});
}
function Home() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(LoveStar, {});
}
//#endregion
export { Home as component };
